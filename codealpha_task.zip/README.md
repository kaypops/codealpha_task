# codealpha_task

This repository contains two separate projects:

- `social-app/` — Open Chirp social app (Node.js)
- `kenny-shop/` — Kenny Supply Co. shop (Django)

See each project folder's README for setup instructions.
