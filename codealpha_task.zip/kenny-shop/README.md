# Kenny Supply Co.

A polished Django e-commerce starter with a real SQLite database, product catalog, session shopping bag, checkout/order records, and user registration/login.

## Run locally

```powershell
python manage.py runserver
```

Open `http://127.0.0.1:8000/`.

## Useful commands

```powershell
python manage.py migrate
python manage.py seed_store
python manage.py createsuperuser
```

Admin: `http://127.0.0.1:8000/admin/`

For deployment, set the `DJANGO_SECRET_KEY` environment variable to a unique secret. This project is configured for local development.

## Demo access
Create a user account in the app to try the storefront.

## Included

- Responsive storefront with Kenny Supply Co. branding
- Product listing filters and product detail pages
- Session-based shopping bag
- Database-backed checkout and order items
- Django user registration, login, and logout
- Admin catalog and order management
