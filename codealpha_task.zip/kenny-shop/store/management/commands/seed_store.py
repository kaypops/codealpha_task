from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from store.models import Product

PRODUCTS = [
    ("Arc Desk Lamp", "arc-desk-lamp", "Desk", "A sculptural aluminum lamp with a warm, focused glow for late ideas.", "129.00", "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1000&q=85", True),
    ("Field Notes Tote", "field-notes-tote", "Carry", "A considered everyday carry in recycled canvas with a quiet green mark.", "68.00", "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1000&q=85", True),
    ("Form Side Table", "form-side-table", "Living", "Clean lines, soft edges, and a steady oak finish for the spaces between.", "214.00", "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1000&q=85", True),
    ("Daily Carry Bottle", "daily-carry-bottle", "Carry", "Double-wall steel, all-day cold, and a cap that never gets in the way.", "42.00", "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=1000&q=85", False),
    ("Grid Organizer", "grid-organizer", "Desk", "A modular home for the small tools that make good work happen.", "56.00", "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1000&q=85", False),
    ("Cedar Candle", "cedar-candle", "Living", "Cedar, bergamot, and a low flame for a slower end to the day.", "34.00", "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=1000&q=85", False),
    ("Studio Field Journal", "studio-field-journal", "Desk", "A cloth-bound notebook for the thoughts that deserve a second look.", "28.00", "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=1000&q=85", True),
    ("Tide Glass Carafe", "tide-glass-carafe", "Living", "A softly formed glass carafe for slow mornings and long tables.", "74.00", "https://images.unsplash.com/photo-1523362628745-0c100150b504?auto=format&fit=crop&w=1000&q=85", False),
    ("Transit Tech Folio", "transit-tech-folio", "Carry", "A slim felt folio that keeps your essential tools close and composed.", "86.00", "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=1000&q=85", True),
]

class Command(BaseCommand):
    def handle(self, *args, **options):
        if not User.objects.filter(username="demo").exists():
            User.objects.create_user(
                username="demo",
                email="demo@kennyshop.local",
                password="KennyShop2026!",
                first_name="Kenny",
                last_name="Demo",
            )
        for name, slug, category, description, price, image_url, featured in PRODUCTS:
            Product.objects.update_or_create(slug=slug, defaults={"name": name, "category": category, "description": description, "price": price, "image_url": image_url, "featured": featured, "stock": 25})
        self.stdout.write(self.style.SUCCESS("Kenny Shop catalog seeded."))
