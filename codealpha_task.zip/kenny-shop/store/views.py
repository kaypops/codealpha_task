from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render
from .models import Order, OrderItem, Product


def cart_items(request):
    cart = request.session.get("cart", {})
    products = Product.objects.filter(id__in=cart.keys())
    items = [{"product": product, "quantity": cart.get(str(product.id), 0), "subtotal": product.price * cart.get(str(product.id), 0)} for product in products]
    return items


def home(request):
    return render(request, "store/home.html", {"featured_products": Product.objects.filter(featured=True)[:4]})


def shop(request):
    category = request.GET.get("category")
    products = Product.objects.all()
    if category in {"Desk", "Carry", "Living"}:
        products = products.filter(category=category)
    return render(request, "store/shop.html", {"products": products, "active_category": category})


def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    return render(request, "store/product_detail.html", {"product": product})


def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart = request.session.setdefault("cart", {})
    key = str(product.id)
    cart[key] = min(cart.get(key, 0) + 1, product.stock)
    request.session.modified = True
    messages.success(request, f"{product.name} added to your bag.")
    return redirect(request.POST.get("next") or request.META.get("HTTP_REFERER", "shop"))


def remove_from_cart(request, product_id):
    cart = request.session.get("cart", {})
    cart.pop(str(product_id), None)
    request.session["cart"] = cart
    return redirect("cart")


def cart(request):
    items = cart_items(request)
    return render(request, "store/cart.html", {"items": items, "total": sum((item["subtotal"] for item in items), Decimal("0"))})


def checkout(request):
    items = cart_items(request)
    if not items:
        return redirect("shop")
    total = sum((item["subtotal"] for item in items), Decimal("0"))
    if request.method == "POST":
        email = request.POST.get("email", "").strip()
        full_name = request.POST.get("full_name", "").strip()
        address = request.POST.get("address", "").strip()
        if email and full_name and address:
            order = Order.objects.create(user=request.user if request.user.is_authenticated else None, email=email, full_name=full_name, address=address, total=total)
            OrderItem.objects.bulk_create([OrderItem(order=order, product=item["product"], quantity=item["quantity"], price=item["product"].price) for item in items])
            request.session["cart"] = {}
            return redirect("checkout_success", order_id=order.id)
        messages.error(request, "Please complete all delivery details.")
    return render(request, "store/checkout.html", {"items": items, "total": total})


def checkout_success(request, order_id):
    return render(request, "store/success.html", {"order": get_object_or_404(Order, id=order_id)})


def register(request):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect("home")
    return render(request, "store/register.html", {"form": form})
