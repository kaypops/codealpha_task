# Kenny on Chirp

A small, warm social network for thoughtful posts and familiar faces. Built with browser-native ES modules, Express 5, SQLite, and cookie-based JWT sessions.

## Requirements

- Node.js 18 or newer
- npm

## Setup

```powershell
npm install
Copy-Item .env.example .env
```

Set `JWT_SECRET` in `.env` to a long random value before starting the server. The default local address is `http://localhost:3000`.

On Windows, double-click `Open Chirp.bat` in this folder to start the server if needed and open Chirp in your default browser. The server runs in a separate command window; close that window to stop it. You can create a desktop shortcut to this batch file using File Explorer's **Send to > Desktop (create shortcut)** option.

```powershell
npm run seed
npm run dev
```

The demo password is `kenny-demo` for each seeded account. Demo accounts are `kenny`, `maya`, `leo`, `noa`, `imani`, and `felix`; their email addresses use the `@chirp.local` domain. The seed script is safe to run more than once and creates 20 posts and example conversations.

Use `npm start` for the production-mode process, `npm test` for isolated API integration tests, `npm run lint` for ESLint, and `npm run check:links` while the server is running to check page routes and internal links. Set `DB_PATH` to move the SQLite database. In production, set `COOKIE_SECURE=true` and configure `CLIENT_ORIGIN` to the exact site origin.

## Pages

| Route                                              | Page                                                   |
| -------------------------------------------------- | ------------------------------------------------------ |
| `/`                                                | Home feed with For You / Following switch and composer |
| `/welcome`                                         | Branded welcome page linking into the app              |
| `/login`, `/register`                              | Account access                                         |
| `/explore`                                         | Search people and posts; discover suggestions          |
| `/post/:id`                                        | Post and complete reply thread                         |
| `/u/:username`                                     | Profile with Posts / Likes tabs                        |
| `/u/:username/followers`, `/u/:username/following` | Follow lists                                           |
| `/notifications`                                   | Likes, comments, and follows                           |
| `/messages`, `/messages/:username`                 | Conversation list and polled chat                      |
| `/settings`                                        | Profile, password, appearance, session                 |
| Unknown URL                                        | Styled 404 page                                        |

## API

All endpoints return JSON. Errors use `{ "error": "message" }`. Feeds accept `limit` (1–50) and `offset`; the Following feed additionally requires a session. Authentication uses an httpOnly, same-site cookie.

| Method | Endpoint                         | Access    | Purpose                             |
| ------ | -------------------------------- | --------- | ----------------------------------- |
| POST   | `/api/auth/register`             | Public    | Create an account and sign in       |
| POST   | `/api/auth/login`                | Public    | Start a session                     |
| POST   | `/api/auth/logout`               | Public    | Clear the session cookie            |
| GET    | `/api/auth/me`                   | Signed in | Get the current profile             |
| GET    | `/api/feed`                      | Public    | Read the global feed                |
| GET    | `/api/feed?type=following`       | Signed in | Read followed accounts              |
| POST   | `/api/posts`                     | Signed in | Create a post (280 characters max)  |
| GET    | `/api/posts/:id`                 | Public    | Read a post and its replies         |
| DELETE | `/api/posts/:id`                 | Owner     | Delete a post                       |
| POST   | `/api/posts/:id/likes`           | Signed in | Toggle a like                       |
| GET    | `/api/posts/:id/comments`        | Public    | List replies                        |
| POST   | `/api/posts/:id/comments`        | Signed in | Add a reply                         |
| DELETE | `/api/comments/:id`              | Owner     | Delete a reply                      |
| GET    | `/api/users/:username`           | Public    | Read a profile and posts            |
| PATCH  | `/api/users/me`                  | Signed in | Edit display name or bio            |
| POST   | `/api/users/:username/follow`    | Signed in | Toggle a follow                     |
| GET    | `/api/users/:username/followers` | Public    | List followers                      |
| GET    | `/api/users/:username/following` | Public    | List followed accounts              |
| GET    | `/api/users/suggestions`         | Public    | Find people to follow               |
| GET    | `/api/users/:username/likes`     | Public    | Read liked posts                    |
| GET    | `/api/search?q=`                 | Public    | Search users and posts              |
| GET    | `/api/messages`                  | Signed in | List conversations and unread count |
| GET    | `/api/messages/:username`        | Signed in | Read thread and mark it read        |
| POST   | `/api/messages/:username`        | Signed in | Send a direct message               |
| GET    | `/api/notifications`             | Signed in | List notifications and unread count |
| POST   | `/api/notifications/read`        | Signed in | Mark notifications read             |
| PUT    | `/api/me`                        | Signed in | Update profile                      |
| PUT    | `/api/me/password`               | Signed in | Change password                     |

`api.http` contains ready-to-run examples for the API. REST Client can reuse the authentication cookie from the registration/login response.

## Project Map

- `server/db/schema.sql`: tables, constraints, foreign keys, and indexes
- `server/db/seed.js`: repeatable demo data
- `server/routes/`: authentication and social API routes
- `server/middleware/`: session checks and centralized error handling
- `public/`: clean-route pages, shared CSS, and shared/page ES modules
- `scripts/check-links.js`: checks page routes and static internal links
- `test/api.test.js`: isolated end-to-end API coverage

## Screenshots

Add desktop and mobile screenshots here after running the app locally.
