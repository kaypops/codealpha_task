import { api, getCurrentUser, initShell, json, toast } from './common.js';

await initShell({ protectedPage: true });
const user = getCurrentUser();
if (!user) throw new Error('Sign-in required.');
const profileForm = document.querySelector('#profile-settings-form');
profileForm.elements.displayName.value = user.displayName;
profileForm.elements.bio.value = user.bio || '';
profileForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const error = document.querySelector('#profile-error');
  error.textContent = '';
  try {
    await api(
      '/me',
      json(
        {
          displayName: profileForm.elements.displayName.value.trim(),
          bio: profileForm.elements.bio.value.trim(),
        },
        'PUT',
      ),
    );
    toast('Profile saved.');
  } catch (caught) {
    error.textContent = caught.message;
  }
});
const passwordForm = document.querySelector('#password-form');
passwordForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const error = document.querySelector('#password-error');
  error.textContent = '';
  const values = Object.fromEntries(new FormData(passwordForm));
  try {
    await api('/me/password', json(values, 'PUT'));
    passwordForm.reset();
    toast('Password updated.');
  } catch (caught) {
    error.textContent = caught.message;
  }
});
document
  .querySelector('#settings-theme')
  .addEventListener('click', () => document.querySelector('.theme-toggle')?.click());
document.querySelector('#logout-button').addEventListener('click', async () => {
  try {
    await api('/auth/logout', { method: 'POST' });
    location.replace('/');
  } catch (error) {
    toast(error.message, 'error');
  }
});
