import {
  api,
  avatar,
  createPostCard,
  emptyState,
  getCurrentUser,
  initShell,
  toast,
} from './common.js';

const list = document.querySelector('#feed-list');
const form = document.querySelector('#post-form');
const textarea = form.elements.content;
const counter = document.querySelector('#post-count');
const mediaInput = document.querySelector('#post-media');
const mediaPreview = document.querySelector('#post-media-preview');
const storiesStrip = document.querySelector('#stories-strip');
let offset = 0;
let loading = false;
const following = new URLSearchParams(location.search).get('feed') === 'following';
let selectedMedia = [];
let activeStories = [];
let storyIndex = 0;
let storyTimer;

function previewFiles(files, target, maxFiles) {
  const supported = new Set([
    'image/jpeg',
    'image/png',
    'image/webp',
    'image/gif',
    'video/mp4',
    'video/webm',
    'video/quicktime',
  ]);
  const selected = [...files];
  if (selected.length > maxFiles) throw new Error(`Choose up to ${maxFiles} media files.`);
  for (const file of selected) {
    if (!supported.has(file.type))
      throw new Error('Choose a JPG, PNG, WebP, GIF, MP4, WebM, or MOV file.');
    if (file.size > 20 * 1024 * 1024) throw new Error('Each media file must be 20 MB or smaller.');
  }
  target.replaceChildren();
  for (const file of selected) {
    const url = URL.createObjectURL(file);
    const item = document.createElement(file.type.startsWith('video/') ? 'video' : 'img');
    item.src = url;
    if (item instanceof HTMLVideoElement) {
      item.muted = true;
      item.playsInline = true;
      item.preload = 'metadata';
    } else item.alt = `Selected image: ${file.name}`;
    target.append(item);
  }
  target.hidden = selected.length === 0;
  return selected;
}

async function load(reset = false) {
  if (loading) return;
  loading = true;
  const more = document.querySelector('#load-more');
  more.disabled = true;
  if (reset) {
    offset = 0;
    list.replaceChildren();
  }
  try {
    const query = new URLSearchParams({ limit: '10', offset: String(offset) });
    if (following) query.set('type', 'following');
    const { posts } = await api(`/feed?${query}`);
    if (!posts.length && offset === 0)
      list.append(
        emptyState(
          following ? 'Your circle is quiet.' : 'A fresh start.',
          following
            ? 'Follow a few people to see their notes here.'
            : 'Be the first to share a thought.',
        ),
      );
    for (const post of posts) list.append(await createPostCard(post));
    offset += posts.length;
    more.hidden = posts.length < 10;
  } catch (error) {
    if (error.status === 401 && following)
      list.append(emptyState('Your circle is waiting.', 'Sign in to see people you follow.'));
    else list.append(emptyState('Could not load the feed.', error.message));
    more.hidden = true;
  } finally {
    loading = false;
    more.disabled = false;
  }
}

const tabs = document.querySelectorAll('.feed-tab');
tabs.forEach((tab) => {
  const isCurrent = following
    ? tab.textContent.trim() === 'Following'
    : tab.textContent.trim() === 'For you';
  tab.classList.toggle('active', isCurrent);
  tab.setAttribute('aria-current', isCurrent ? 'page' : 'false');
});

textarea.addEventListener('input', () => {
  counter.textContent = `${textarea.value.length} / 280`;
  counter.classList.toggle('near-limit', textarea.value.length > 250);
});
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!textarea.value.trim()) return;
  const submit = form.querySelector('[type=submit]');
  submit.disabled = true;
  try {
    const payload = new FormData();
    payload.append('content', textarea.value.trim());
    selectedMedia.forEach((file) => payload.append('media', file));
    const { post } = await api('/posts', { method: 'POST', body: payload });
    const card = await createPostCard(post);
    list.prepend(card);
    textarea.value = '';
    counter.textContent = '0 / 280';
    mediaInput.value = '';
    selectedMedia = [];
    previewFiles([], mediaPreview, 4);
    document.querySelector('.empty-state')?.remove();
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    submit.disabled = false;
  }
});

document.querySelector('#load-more').addEventListener('click', () => load());
mediaInput.addEventListener('change', () => {
  try {
    selectedMedia = previewFiles(mediaInput.files, mediaPreview, 4);
  } catch (error) {
    mediaInput.value = '';
    selectedMedia = [];
    previewFiles([], mediaPreview, 4);
    toast(error.message, 'error');
  }
});
window.addEventListener('chirp:new-post', async (event) =>
  list.prepend(await createPostCard(event.detail)),
);

function renderStoryMedia(story, container) {
  if (!story.mediaUrl) return;
  const media = document.createElement(story.mediaType === 'video' ? 'video' : 'img');
  media.src = story.mediaUrl;
  if (story.mediaType === 'video') {
    media.controls = true;
    media.autoplay = true;
    media.playsInline = true;
  } else media.alt = `Story from ${story.displayName}`;
  container.append(media);
}

function showStory(index) {
  const dialog = document.querySelector('#story-view-dialog');
  if (!activeStories.length) return;
  storyIndex = (index + activeStories.length) % activeStories.length;
  const story = activeStories[storyIndex];
  dialog.replaceChildren();
  const card = document.createElement('article');
  card.className = 'story-card';
  const top = document.createElement('header');
  top.className = 'story-card-header';
  top.append(avatar(story.displayName, 'sm'));
  const label = document.createElement('div');
  label.className = 'story-card-author';
  const author = document.createElement('a');
  author.href = `/u/${encodeURIComponent(story.username)}`;
  author.textContent = story.displayName;
  const stamp = document.createElement('span');
  stamp.textContent = '24-hour Story';
  label.append(author, stamp);
  const close = document.createElement('button');
  close.className = 'story-close';
  close.type = 'button';
  close.setAttribute('aria-label', 'Close Story');
  close.textContent = '×';
  close.addEventListener('click', () => dialog.close());
  top.append(label, close);
  const media = document.createElement('div');
  media.className = 'story-card-media';
  renderStoryMedia(story, media);
  const caption = document.createElement('p');
  caption.className = 'story-card-caption';
  caption.textContent = story.content;
  const previous = document.createElement('button');
  previous.className = 'story-step story-previous';
  previous.type = 'button';
  previous.setAttribute('aria-label', 'Previous Story');
  previous.textContent = '‹';
  previous.addEventListener('click', () => showStory(storyIndex - 1));
  const next = document.createElement('button');
  next.className = 'story-step story-next';
  next.type = 'button';
  next.setAttribute('aria-label', 'Next Story');
  next.textContent = '›';
  next.addEventListener('click', () => showStory(storyIndex + 1));
  card.append(top, media, caption, previous, next);
  dialog.append(card);
  if (!dialog.open) dialog.showModal();
  api(`/stories/${story.id}/view`, { method: 'POST' }).catch(() => {});
  clearTimeout(storyTimer);
  storyTimer = window.setTimeout(() => showStory(storyIndex + 1), 8000);
}

function openStoryComposer() {
  if (!getCurrentUser()) {
    location.href = `/login?next=${encodeURIComponent(location.pathname + location.search)}`;
    return;
  }
  const dialog = document.querySelector('#story-create-dialog');
  dialog.replaceChildren();
  const form = document.createElement('form');
  form.className = 'modal-inner form-stack story-form';
  const heading = document.createElement('div');
  heading.className = 'modal-top';
  const title = document.createElement('div');
  const h2 = document.createElement('h2');
  h2.textContent = 'Share a Story';
  const hint = document.createElement('p');
  hint.textContent = 'A quick moment, gone in 24 hours.';
  title.append(h2, hint);
  const close = document.createElement('button');
  close.className = 'icon-only';
  close.type = 'button';
  close.setAttribute('aria-label', 'Close');
  close.textContent = '×';
  close.addEventListener('click', () => dialog.close());
  heading.append(title, close);
  const caption = document.createElement('textarea');
  caption.name = 'content';
  caption.maxLength = 280;
  caption.placeholder = 'Add a note to your Story…';
  caption.setAttribute('aria-label', 'Story caption');
  const picker = document.createElement('label');
  picker.className = 'story-upload-picker';
  picker.textContent = 'Choose a photo or video';
  const input = document.createElement('input');
  input.type = 'file';
  input.name = 'media';
  input.accept = 'image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime';
  input.className = 'visually-hidden';
  const preview = document.createElement('div');
  preview.className = 'story-upload-preview';
  preview.hidden = true;
  picker.append(input);
  input.addEventListener('change', () => {
    try {
      previewFiles(input.files, preview, 1);
    } catch (error) {
      input.value = '';
      previewFiles([], preview, 1);
      toast(error.message, 'error');
    }
  });
  const errorText = document.createElement('p');
  errorText.className = 'form-error';
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'primary-button full-button';
  submit.textContent = 'Share Story';
  form.append(heading, caption, picker, preview, errorText, submit);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    submit.disabled = true;
    const data = new FormData(form);
    try {
      const { story } = await api('/stories', { method: 'POST', body: data });
      activeStories.unshift(story);
      renderStories();
      dialog.close();
      showStory(0);
      toast('Your Story is up.');
    } catch (error) {
      errorText.textContent = error.message;
    } finally {
      submit.disabled = false;
    }
  });
  dialog.append(form);
  dialog.showModal();
  caption.focus();
}

function renderStories() {
  storiesStrip.replaceChildren();
  const add = document.createElement('button');
  add.className = 'story-person story-add';
  add.type = 'button';
  add.append(avatar(getCurrentUser()?.displayName || 'Your Story', 'md'));
  const addLabel = document.createElement('span');
  addLabel.textContent = 'Your Story';
  const addMark = document.createElement('span');
  addMark.className = 'story-add-mark';
  addMark.textContent = '+';
  add.append(addMark, addLabel);
  add.addEventListener('click', openStoryComposer);
  storiesStrip.append(add);
  const seenUsers = new Set();
  activeStories.forEach((story, index) => {
    if (seenUsers.has(story.userId) || story.userId === getCurrentUser()?.id) return;
    seenUsers.add(story.userId);
    const button = document.createElement('button');
    button.className = `story-person${story.viewed ? ' story-viewed' : ''}`;
    button.type = 'button';
    button.append(avatar(story.displayName, 'md'));
    const name = document.createElement('span');
    name.textContent = story.displayName.split(' ')[0];
    button.append(name);
    button.addEventListener('click', () => showStory(index));
    storiesStrip.append(button);
  });
}

async function loadStories() {
  try {
    const { stories } = await api('/stories');
    activeStories = stories;
  } catch {
    activeStories = [];
  }
  renderStories();
}

document
  .querySelector('#story-view-dialog')
  .addEventListener('close', () => clearTimeout(storyTimer));

await initShell();
const signedInUser = getCurrentUser();
form.hidden = !signedInUser || following;
if (signedInUser) {
  const holder = document.querySelector('#composer-avatar');
  holder.textContent = signedInUser.displayName
    .split(/\s+/)
    .map((part) => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  textarea.placeholder = `What’s on your mind, ${signedInUser.displayName.split(' ')[0]}?`;
}
await load(true);
await loadStories();
