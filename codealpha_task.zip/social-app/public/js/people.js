import { api, emptyState, initShell, personRow } from './common.js';

await initShell();
const kind = document.body.dataset.page;
const parts = location.pathname.split('/').filter(Boolean);
const username = decodeURIComponent(parts[1] || '');
const title = kind === 'followers' ? 'Followers' : 'Following';
const root = document.querySelector('#people-page');
const heading = document.createElement('section');
heading.className = 'page-heading';
const eyebrow = document.createElement('span');
eyebrow.className = 'eyebrow';
eyebrow.textContent = `@${username}`;
const h1 = document.createElement('h1');
h1.textContent = title;
const back = document.createElement('a');
back.className = 'text-link';
back.href = `/u/${encodeURIComponent(username)}`;
back.textContent = '← Back to profile';
heading.append(eyebrow, h1, back);
try {
  const { users } = await api(`/users/${encodeURIComponent(username)}/${kind}`);
  const list = document.createElement('section');
  list.className = 'people-grid';
  if (users.length) users.forEach((user) => list.append(personRow(user)));
  else
    list.append(
      emptyState(`No ${title.toLowerCase()} yet.`, 'This circle is just getting started.'),
    );
  root.replaceChildren(heading, list);
} catch (error) {
  root.replaceChildren(heading, emptyState('Could not load this list.', error.message));
}
