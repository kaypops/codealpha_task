import {
  api,
  avatarLink,
  createPostCard,
  emptyState,
  getCurrentUser,
  initShell,
  json,
  timeAgo,
  toast,
} from './common.js';

await initShell();
const root = document.querySelector('#post-detail');
const id = location.pathname.split('/').filter(Boolean).at(-1);
const node = (tag, cls, value = '') => {
  const item = document.createElement(tag);
  item.className = cls;
  item.textContent = value;
  return item;
};
try {
  const { post, comments } = await api(`/posts/${encodeURIComponent(id)}`);
  root.replaceChildren(await createPostCard(post));
  const section = node('section', 'comment-section');
  section.append(node('h2', 'comment-heading', `Replies · ${comments.length}`));
  const list = node('div', 'comment-list');
  function addComment(comment) {
    const item = node('article', 'comment-item');
    item.append(avatarLink(comment, 'sm'));
    const content = node('div', 'comment-content');
    const meta = node('div', 'comment-meta');
    const author = document.createElement('a');
    author.href = `/u/${encodeURIComponent(comment.username)}`;
    author.append(node('strong', '', comment.displayName));
    meta.append(author, node('span', '', `@${comment.username} · ${timeAgo(comment.createdAt)}`));
    content.append(meta, node('p', '', comment.content));
    if (getCurrentUser()?.id === comment.userId) {
      const remove = node('button', 'post-menu', '×');
      remove.type = 'button';
      remove.setAttribute('aria-label', 'Delete comment');
      remove.addEventListener('click', async () => {
        if (!confirm('Delete this reply?')) return;
        try {
          await api(`/comments/${comment.id}`, { method: 'DELETE' });
          item.remove();
          section.querySelector('.comment-heading').textContent =
            `Replies · ${list.children.length}`;
        } catch (error) {
          toast(error.message, 'error');
        }
      });
      meta.append(remove);
    }
    item.append(content);
    list.append(item);
  }
  comments.forEach(addComment);
  if (!comments.length)
    list.append(emptyState('No replies yet.', 'Leave the first thoughtful reply.'));
  section.append(list);
  if (getCurrentUser()) {
    const form = node('form', 'comment-form');
    const input = document.createElement('input');
    input.name = 'content';
    input.maxLength = 280;
    input.required = true;
    input.placeholder = 'Write a thoughtful reply…';
    input.setAttribute('aria-label', 'Write a reply');
    const submit = node('button', '', 'Reply');
    submit.type = 'submit';
    form.append(input, submit);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      submit.disabled = true;
      try {
        const { comment } = await api(
          `/posts/${post.id}/comments`,
          json({ content: input.value.trim() }),
        );
        list.querySelector('.empty-state')?.remove();
        addComment(comment);
        input.value = '';
        section.querySelector('.comment-heading').textContent =
          `Replies · ${list.querySelectorAll('.comment-item').length}`;
      } catch (error) {
        toast(error.message, 'error');
      } finally {
        submit.disabled = false;
      }
    });
    section.append(form);
  } else {
    const signIn = document.createElement('a');
    signIn.href = `/login?next=${encodeURIComponent(location.pathname)}`;
    signIn.className = 'edit-button';
    signIn.textContent = 'Sign in to reply';
    section.append(signIn);
  }
  root.append(section);
} catch (error) {
  root.replaceChildren(emptyState('Post not found.', error.message));
}
