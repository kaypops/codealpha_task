import {
  api,
  avatar,
  createPostCard,
  emptyState,
  followButton,
  getCurrentUser,
  initShell,
} from './common.js';

await initShell();
const username = decodeURIComponent(location.pathname.split('/').filter(Boolean).at(-1));
const root = document.querySelector('#profile-content');
const node = (tag, cls, value = '') => {
  const item = document.createElement(tag);
  item.className = cls;
  item.textContent = value;
  return item;
};
try {
  const { user, posts } = await api(`/users/${encodeURIComponent(username)}`);
  const isOwn = getCurrentUser()?.id === user.id;
  const cover = node('section', 'profile-hero');
  const top = node('div', 'profile-topline');
  const profileAvatar = document.createElement('a');
  profileAvatar.className = 'profile-avatar-link';
  profileAvatar.href = `/u/${encodeURIComponent(user.username)}`;
  profileAvatar.setAttribute('aria-label', `Open ${user.displayName}'s profile`);
  profileAvatar.append(avatar(user.displayName, 'lg'));
  top.append(profileAvatar);
  const actions = node('div', 'profile-actions');
  if (isOwn) {
    const edit = document.createElement('a');
    edit.href = '/settings';
    edit.className = 'edit-button';
    edit.textContent = 'Edit profile';
    actions.append(edit);
  } else if (getCurrentUser()) {
    actions.append(
      followButton(user, {
        onChange: (updated) => {
          cover.querySelector('[data-stat="followers"]').textContent = updated.followerCount;
        },
      }),
    );
    const message = document.createElement('a');
    message.href = `/messages/${encodeURIComponent(user.username)}`;
    message.className = 'edit-button';
    message.textContent = 'Message';
    actions.append(message);
  }
  top.append(actions);
  const details = node('div', 'profile-copy');
  details.append(node('h1', '', user.displayName), node('span', 'handle', `@${user.username}`));
  if (user.bio) details.append(node('p', '', user.bio));
  details.append(
    node(
      'span',
      'profile-joined',
      `Joined ${new Intl.DateTimeFormat(undefined, { month: 'long', year: 'numeric' }).format(new Date(user.createdAt))}`,
    ),
  );
  const stats = node('div', 'profile-stats');
  const postCount = node('span', 'profile-stat', `${user.postCount} posts`);
  const followers = document.createElement('a');
  followers.className = 'profile-stat';
  followers.dataset.stat = 'followers';
  followers.href = `/u/${encodeURIComponent(user.username)}/followers`;
  followers.textContent = `${user.followerCount} followers`;
  const following = document.createElement('a');
  following.className = 'profile-stat';
  following.href = `/u/${encodeURIComponent(user.username)}/following`;
  following.textContent = `${user.followingCount} following`;
  stats.append(postCount, followers, following);
  cover.append(top, details, stats);
  const tabs = node('nav', 'profile-tabs');
  const postsTab = document.createElement('a');
  postsTab.href = `/u/${encodeURIComponent(user.username)}`;
  postsTab.textContent = 'Posts';
  const likesTab = document.createElement('a');
  likesTab.href = `/u/${encodeURIComponent(user.username)}?tab=likes`;
  likesTab.textContent = 'Likes';
  const likesSelected = new URLSearchParams(location.search).get('tab') === 'likes';
  (likesSelected ? likesTab : postsTab).classList.add('active');
  tabs.append(postsTab, likesTab);
  root.replaceChildren(cover, tabs);
  const list = node('section', 'post-list');
  const visiblePosts = likesSelected
    ? (await api(`/users/${encodeURIComponent(username)}/likes`)).posts
    : posts;
  for (const post of visiblePosts) list.append(await createPostCard(post));
  if (!visiblePosts.length)
    list.append(
      emptyState(
        likesSelected ? 'No liked posts yet.' : 'No notes yet.',
        'When something is shared, it will show up here.',
      ),
    );
  root.append(list);
} catch (error) {
  root.replaceChildren(emptyState('Profile not found.', error.message));
}
