import {
  api,
  avatar,
  clearUnreadBadge,
  emptyState,
  getCurrentUser,
  initShell,
  json,
  timeAgo,
  toast,
} from './common.js';

await initShell({ protectedPage: true });
const currentUser = getCurrentUser();
const conversationRoot = document.querySelector('#conversation-list');
const panel = document.querySelector('#chat-panel');
const username = location.pathname.split('/').filter(Boolean)[1]
  ? decodeURIComponent(location.pathname.split('/').filter(Boolean)[1])
  : '';
let activeUsername = username;
let pollTimer;
const node = (tag, cls, value = '') => {
  const item = document.createElement(tag);
  item.className = cls;
  item.textContent = value;
  return item;
};

async function loadConversations() {
  const { conversations } = await api('/messages');
  conversationRoot.replaceChildren();
  if (!conversations.length) {
    conversationRoot.append(
      emptyState('No conversations yet.', 'Visit a profile and send the first note.'),
    );
    return conversations;
  }
  for (const conversation of conversations) {
    const row = document.createElement('div');
    row.className = `conversation-item${activeUsername === conversation.username ? ' active' : ''}`;
    const person = document.createElement('a');
    person.href = `/u/${encodeURIComponent(conversation.username)}`;
    person.setAttribute('aria-label', `Open ${conversation.displayName}'s profile`);
    person.append(avatar(conversation.displayName, 'md'));
    const copy = node('span', 'conversation-copy');
    copy.append(
      node('strong', '', conversation.displayName),
      node('span', '', conversation.lastMessage),
      node('time', '', timeAgo(conversation.lastMessageAt)),
    );
    const threadLink = document.createElement('a');
    threadLink.className = 'conversation-thread-link';
    threadLink.href = `/messages/${encodeURIComponent(conversation.username)}`;
    threadLink.append(copy);
    row.append(person, threadLink);
    if (conversation.unreadCount)
      row.append(node('span', 'unread-count', conversation.unreadCount));
    conversationRoot.append(row);
  }
  return conversations;
}

async function loadThread() {
  if (!activeUsername) {
    panel.replaceChildren(
      emptyState('Your messages live here.', 'Choose a conversation or start one from a profile.'),
    );
    return;
  }
  try {
    const { user, messages } = await api(`/messages/${encodeURIComponent(activeUsername)}`);
    clearUnreadBadge('messages');
    const heading = node('header', 'chat-header');
    const link = document.createElement('a');
    link.href = `/u/${encodeURIComponent(user.username)}`;
    link.append(avatar(user.displayName, 'sm'), node('strong', '', user.displayName));
    heading.append(link);
    const thread = node('div', 'chat-thread');
    if (!messages.length)
      thread.append(node('p', 'chat-start-note', `Say hello to ${user.displayName}.`));
    for (const message of messages) {
      const bubble = node(
        'article',
        `message-bubble${message.senderId === currentUser.id ? ' sent' : ' received'}`,
        message.content,
      );
      const stamp = node('time', '', timeAgo(message.createdAt));
      bubble.append(stamp);
      thread.append(bubble);
    }
    const form = node('form', 'message-form');
    const input = document.createElement('input');
    input.name = 'content';
    input.maxLength = 2000;
    input.required = true;
    input.placeholder = `Message ${user.displayName}…`;
    input.setAttribute('aria-label', 'Write a message');
    const submit = node('button', 'primary-button', 'Send');
    submit.type = 'submit';
    form.append(input, submit);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      submit.disabled = true;
      try {
        await api(
          `/messages/${encodeURIComponent(activeUsername)}`,
          json({ content: input.value.trim() }),
        );
        input.value = '';
        await loadThread();
        await loadConversations();
      } catch (error) {
        toast(error.message, 'error');
      } finally {
        submit.disabled = false;
      }
    });
    panel.replaceChildren(heading, thread, form);
    thread.scrollTop = thread.scrollHeight;
    await loadConversations();
  } catch (error) {
    panel.replaceChildren(emptyState('Conversation unavailable.', error.message));
  }
}

try {
  const conversations = await loadConversations();
  if (!activeUsername && conversations.length) activeUsername = conversations[0].username;
  await loadThread();
  if (activeUsername) {
    pollTimer = window.setInterval(async () => {
      await loadThread();
    }, 4000);
    window.addEventListener('pagehide', () => window.clearInterval(pollTimer), { once: true });
  }
} catch (error) {
  panel.replaceChildren(emptyState('Messages could not load.', error.message));
}
