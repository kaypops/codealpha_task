import {
  api,
  avatarLink,
  clearUnreadBadge,
  emptyState,
  initShell,
  toast,
  timeAgo,
} from './common.js';

await initShell({ protectedPage: true });
const root = document.querySelector('#notifications-list');
try {
  const { notifications } = await api('/notifications');
  root.replaceChildren();
  if (!notifications.length)
    root.append(emptyState('All caught up.', 'When people respond, you’ll see it here.'));
  for (const item of notifications) {
    const row = document.createElement('article');
    row.className = `notification-row${item.readAt ? '' : ' unread'}`;
    const actor = { username: item.actorUsername, displayName: item.actorDisplayName };
    row.append(avatarLink(actor, 'md'));
    const content = document.createElement('div');
    content.className = 'notification-copy';
    const actorLink = document.createElement('a');
    actorLink.href = `/u/${encodeURIComponent(actor.username)}`;
    actorLink.textContent = actor.displayName;
    const verb =
      item.type === 'like'
        ? 'liked your post'
        : item.type === 'comment'
          ? 'replied to your post'
          : 'started following you';
    const sentence = document.createElement('p');
    sentence.append(actorLink, document.createTextNode(` ${verb}`));
    content.append(sentence);
    if (item.postId) {
      const post = document.createElement('a');
      post.href = `/post/${item.postId}`;
      post.className = 'notification-post';
      post.textContent = item.postContent || 'View post';
      content.append(post);
    }
    content.append(
      Object.assign(document.createElement('time'), {
        className: 'post-time',
        textContent: timeAgo(item.createdAt),
      }),
    );
    row.append(content);
    root.append(row);
  }
  if (notifications.some((item) => !item.readAt)) {
    await api('/notifications/read', { method: 'POST' });
    document
      .querySelectorAll('.notification-row.unread')
      .forEach((row) => row.classList.remove('unread'));
    clearUnreadBadge('notifications');
  }
} catch (error) {
  toast(error.message, 'error');
  root.replaceChildren(emptyState('Could not load notifications.', error.message));
}
