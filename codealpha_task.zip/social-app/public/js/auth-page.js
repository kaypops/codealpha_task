import { api, getCurrentUser, initShell, json, toast } from './common.js';

const mode = document.body.dataset.page;
await initShell({ authPage: true });
if (getCurrentUser()) location.replace('/');
const form = document.querySelector('#auth-form');
const errorText = document.querySelector('#form-error');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  errorText.textContent = '';
  const submit = form.querySelector('[type=submit]');
  submit.disabled = true;
  const values = Object.fromEntries(new FormData(form));
  try {
    const { user } = await api(`/auth/${mode}`, json(values));
    if (!user) throw new Error('Your account could not be loaded.');
    const requested = new URLSearchParams(location.search).get('next') || '/';
    const destination = requested.startsWith('/') && !requested.startsWith('//') ? requested : '/';
    toast(mode === 'login' ? 'Welcome back.' : 'Welcome to Chirp.');
    location.replace(destination);
  } catch (error) {
    errorText.textContent = error.message;
  } finally {
    submit.disabled = false;
  }
});
