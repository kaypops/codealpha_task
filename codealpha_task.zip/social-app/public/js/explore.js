import { api, createPostCard, emptyState, initShell, personRow } from './common.js';

await initShell();
const params = new URLSearchParams(location.search);
const input = document.querySelector('#search-query');
input.value = params.get('q') || '';
const usersNode = document.querySelector('#search-users');
const postsNode = document.querySelector('#search-posts');
const suggestionsNode = document.querySelector('#suggestions');

async function showSuggestions() {
  try {
    const { users } = await api('/users/suggestions');
    suggestionsNode.replaceChildren(...users.map((user) => personRow(user)));
    if (!users.length)
      suggestionsNode.append(
        emptyState('You’re all caught up.', 'Everyone is already in your circle.'),
      );
  } catch (error) {
    suggestionsNode.append(emptyState('Suggestions are taking a break.', error.message));
  }
}

async function search(term) {
  usersNode.replaceChildren();
  postsNode.replaceChildren();
  if (!term.trim()) {
    usersNode.append(
      emptyState('Search for a person or a post.', 'Try a name, username, or phrase.'),
    );
    postsNode.append(
      emptyState('Your next favorite could be here.', 'Search to find a conversation.'),
    );
    return;
  }
  try {
    const { users, posts } = await api(`/search?q=${encodeURIComponent(term.trim())}`);
    users.forEach((user) => usersNode.append(personRow(user)));
    postsNode.append(...(await Promise.all(posts.map(createPostCard))));
    if (!users.length)
      usersNode.append(emptyState('No people found.', 'Try another name or username.'));
    if (!posts.length) postsNode.append(emptyState('No posts found.', 'Try a different phrase.'));
  } catch (error) {
    usersNode.append(emptyState('Search did not finish.', error.message));
  }
}

document.querySelector('#search-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const q = input.value.trim();
  history.replaceState(null, '', q ? `/explore?q=${encodeURIComponent(q)}` : '/explore');
  search(q);
});
await showSuggestions();
await search(input.value);
