const $ = (selector, root = document) => root.querySelector(selector);
let currentUser = null;
const pageName = document.body.dataset.page || 'home';
let activePage = ['followers', 'following'].includes(pageName) ? 'profile' : pageName;

export async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    credentials: 'same-origin',
    ...options,
    headers: {
      ...(options.body && !(options.body instanceof FormData)
        ? { 'Content-Type': 'application/json' }
        : {}),
      ...options.headers,
    },
  });
  const data = response.status === 204 ? {} : await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Request failed (${response.status}).`);
    error.status = response.status;
    throw error;
  }
  return data;
}

export const json = (value, method = 'POST') => ({ method, body: JSON.stringify(value) });
export const getCurrentUser = () => currentUser;
export const escapeHTML = (value = '') =>
  String(value).replace(
    /[&<>"']/g,
    (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char],
  );
export const timeAgo = (value) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const minutes = Math.floor((Date.now() - date.getTime()) / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m`;
  if (minutes < 1440) return `${Math.floor(minutes / 60)}h`;
  if (minutes < 10080) return `${Math.floor(minutes / 1440)}d`;
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(date);
};

export function toast(message, kind = 'success') {
  let region = $('#toast-region');
  if (!region) {
    region = document.createElement('div');
    region.id = 'toast-region';
    region.className = 'toast-region';
    region.setAttribute('aria-live', 'polite');
    document.body.append(region);
  }
  const item = document.createElement('div');
  item.className = `toast ${kind}`;
  item.textContent = message;
  region.append(item);
  window.setTimeout(() => item.remove(), 3600);
}

export function avatar(name = '?', size = 'md') {
  const node = document.createElement('span');
  node.className = `avatar avatar-${size}`;
  node.setAttribute('aria-hidden', 'true');
  node.textContent =
    name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0] || '')
      .join('')
      .toUpperCase() || '?';
  return node;
}

export function avatarLink(user, size = 'md') {
  const link = document.createElement('a');
  link.href = `/u/${encodeURIComponent(user.username)}`;
  link.className = 'avatar-link';
  link.setAttribute('aria-label', `Open ${user.displayName || user.username}'s profile`);
  link.append(avatar(user.displayName || user.username, size));
  return link;
}

function text(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  node.textContent = value ?? '';
  return node;
}

function navLink(label, href, key, badge = 0) {
  const link = document.createElement('a');
  link.className = `nav-link${activePage === key ? ' active' : ''}`;
  link.href = href;
  link.dataset.navKey = key;
  const labelNode = text('span', '', label);
  link.append(labelNode);
  if (badge > 0) link.append(text('span', 'nav-badge', badge > 99 ? '99+' : String(badge)));
  return link;
}

function iconButton(label, symbol, className = '') {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = className;
  button.setAttribute('aria-label', label);
  button.title = label;
  button.textContent = symbol;
  return button;
}

function toggleTheme() {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('kenny-theme', next);
}

function renderHeader() {
  const header = $('#site-header');
  if (!header) return;
  header.replaceChildren();
  const brand = document.createElement('a');
  brand.className = 'wordmark';
  brand.href = '/';
  brand.setAttribute('aria-label', 'Kenny on Chirp home');
  brand.append(text('span', 'brand-mark', 'k'), text('span', 'wordmark-copy', 'kenny on chirp'));
  const search = document.createElement('form');
  search.className = 'search-box header-search';
  search.action = '/explore';
  search.method = 'get';
  search.innerHTML =
    '<span aria-hidden="true">⌕</span><input name="q" type="search" placeholder="Find your people" aria-label="Search Chirp"><kbd>/</kbd>';
  const actions = document.createElement('div');
  actions.className = 'header-actions';
  actions.append(iconButton('Switch color theme', '☼', 'icon-button theme-toggle'));
  if (currentUser) {
    const profile = document.createElement('a');
    profile.href = `/u/${encodeURIComponent(currentUser.username)}`;
    profile.className = 'header-user';
    profile.append(
      avatar(currentUser.displayName, 'sm'),
      text('span', 'account-name', currentUser.displayName),
    );
    actions.append(profile);
  } else {
    const signIn = document.createElement('a');
    signIn.href = `/login?next=${encodeURIComponent(location.pathname + location.search)}`;
    signIn.className = 'header-auth-button';
    signIn.textContent = 'Sign in';
    actions.append(signIn);
  }
  header.append(brand, search, actions);
  search.addEventListener('submit', (event) => {
    event.preventDefault();
    const q = new FormData(search).get('q')?.toString().trim();
    location.href = q ? `/explore?q=${encodeURIComponent(q)}` : '/explore';
  });
}

function renderNavigation(counts) {
  const desktop = $('#desktop-nav');
  const mobile = $('#mobile-nav');
  if (!desktop || !mobile) return;
  desktop.replaceChildren();
  const nav = document.createElement('nav');
  nav.className = 'main-nav';
  nav.setAttribute('aria-label', 'Main navigation');
  nav.append(
    navLink('Home', '/', 'home'),
    navLink('Explore', '/explore', 'explore'),
    navLink('Notifications', '/notifications', 'notifications', counts.notifications),
    navLink('Messages', '/messages', 'messages', counts.messages),
  );
  if (currentUser)
    nav.append(navLink('Profile', `/u/${encodeURIComponent(currentUser.username)}`, 'profile'));
  nav.append(navLink('Settings', '/settings', 'settings'));
  const postButton = text('button', 'nav-link compose-nav', '＋  Post');
  postButton.type = 'button';
  postButton.addEventListener('click', openComposer);
  nav.append(postButton);
  const footer = document.createElement('div');
  footer.className = 'rail-bottom';
  footer.append(
    text('span', 'rail-caption', currentUser ? `@${currentUser.username}` : 'A little more human.'),
  );
  if (currentUser) {
    const signOut = text('button', 'rail-signout', 'Sign out');
    signOut.type = 'button';
    signOut.addEventListener('click', logout);
    footer.append(signOut);
  }
  desktop.append(nav, footer);
  mobile.replaceChildren();
  mobile.setAttribute('aria-label', 'Mobile navigation');
  mobile.append(navLink('Home', '/', 'home'), navLink('Explore', '/explore', 'explore'));
  const center = text('button', 'mobile-post-button', '＋');
  center.type = 'button';
  center.setAttribute('aria-label', 'Create a post');
  center.addEventListener('click', openComposer);
  mobile.append(
    center,
    navLink('Notifications', '/notifications', 'notifications', counts.notifications),
    navLink('Messages', '/messages', 'messages', counts.messages),
  );
}

async function logout() {
  try {
    await api('/auth/logout', { method: 'POST' });
    location.href = '/';
  } catch (error) {
    toast(error.message, 'error');
  }
}

function openComposer() {
  if (!currentUser) {
    location.href = `/login?next=${encodeURIComponent(location.pathname + location.search)}`;
    return;
  }
  const homeComposer = $('#post-form textarea');
  if (homeComposer) {
    homeComposer.focus();
    homeComposer.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }
  let dialog = $('#composer-dialog');
  if (!dialog) {
    dialog = document.createElement('dialog');
    dialog.id = 'composer-dialog';
    dialog.className = 'modal-dialog';
    document.body.append(dialog);
  }
  dialog.replaceChildren();
  const form = document.createElement('form');
  form.className = 'modal-inner form-stack';
  form.method = 'dialog';
  form.append(text('h2', '', 'A thought for your people'));
  const input = document.createElement('textarea');
  input.name = 'content';
  input.maxLength = 280;
  input.required = true;
  input.placeholder = 'What’s on your mind?';
  input.setAttribute('aria-label', 'Write a post');
  const mediaPicker = document.createElement('label');
  mediaPicker.className = 'media-picker';
  mediaPicker.textContent = '▧  Add photos or video';
  const files = document.createElement('input');
  files.type = 'file';
  files.name = 'media';
  files.accept = 'image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime';
  files.multiple = true;
  files.className = 'visually-hidden';
  mediaPicker.append(files);
  const preview = document.createElement('div');
  preview.className = 'media-preview-grid';
  preview.hidden = true;
  files.addEventListener('change', () => {
    preview.replaceChildren();
    for (const file of [...files.files].slice(0, 4)) {
      const url = URL.createObjectURL(file);
      const item = file.type.startsWith('video/')
        ? document.createElement('video')
        : document.createElement('img');
      item.src = url;
      if (item instanceof HTMLVideoElement) {
        item.muted = true;
        item.playsInline = true;
        item.preload = 'metadata';
      } else item.alt = `Selected image: ${file.name}`;
      preview.append(item);
    }
    preview.hidden = files.files.length === 0;
  });
  const count = text('span', 'char-count', '0 / 280');
  input.addEventListener('input', () => {
    count.textContent = `${input.value.length} / 280`;
  });
  const actions = document.createElement('div');
  actions.className = 'composer-footer';
  const cancel = text('button', 'edit-button', 'Cancel');
  cancel.type = 'button';
  cancel.addEventListener('click', () => dialog.close());
  const submit = text('button', 'primary-button', 'Post');
  submit.type = 'submit';
  actions.append(count, cancel, submit);
  form.append(input, mediaPicker, preview, actions);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    submit.disabled = true;
    try {
      const payload = new FormData();
      payload.append('content', input.value.trim());
      for (const file of files.files) payload.append('media', file);
      const { post } = await api('/posts', { method: 'POST', body: payload });
      dialog.close();
      toast('Your thought is out there.');
      if (activePage === 'home')
        window.dispatchEvent(new CustomEvent('chirp:new-post', { detail: post }));
      else location.href = '/';
    } catch (error) {
      toast(error.message, 'error');
    } finally {
      submit.disabled = false;
    }
  });
  dialog.append(form);
  dialog.showModal();
  input.focus();
}

export async function createPostCard(post) {
  const card = document.createElement('article');
  card.className = 'post-card';
  card.dataset.postId = post.id;
  const header = document.createElement('header');
  header.className = 'post-header';
  header.append(avatarLink({ username: post.username, displayName: post.displayName }, 'md'));
  const author = document.createElement('a');
  author.href = `/u/${encodeURIComponent(post.username)}`;
  author.className = 'post-author';
  author.append(text('strong', '', post.displayName), text('span', '', `@${post.username}`));
  const stamp = document.createElement('a');
  stamp.href = `/post/${post.id}`;
  stamp.className = 'post-time';
  stamp.textContent = timeAgo(post.createdAt);
  header.append(author, stamp);
  if (currentUser && currentUser.id === post.userId) {
    const remove = iconButton('Delete post', '···', 'post-menu');
    remove.addEventListener('click', async () => {
      if (!window.confirm('Delete this post?')) return;
      try {
        await api(`/posts/${post.id}`, { method: 'DELETE' });
        card.remove();
        toast('Post deleted.');
      } catch (error) {
        toast(error.message, 'error');
      }
    });
    header.append(remove);
  }
  const body = text('a', 'post-body post-body-link', post.content);
  body.href = `/post/${post.id}`;
  body.setAttribute('aria-label', 'Open post and replies');
  const media = document.createElement('div');
  media.className = `post-media-grid${post.media?.length === 1 ? ' single-media' : ''}`;
  for (const attachment of post.media || []) {
    if (attachment.mediaType === 'video') {
      const video = document.createElement('video');
      video.src = attachment.url;
      video.controls = true;
      video.preload = 'metadata';
      video.playsInline = true;
      video.setAttribute('aria-label', 'Post video');
      media.append(video);
    } else {
      const image = document.createElement('img');
      image.src = attachment.url;
      image.alt = `Photo shared by ${post.displayName}`;
      image.loading = 'lazy';
      media.append(image);
    }
  }
  const actions = document.createElement('div');
  actions.className = 'post-actions';
  const like = text(
    'button',
    `post-action${post.liked ? ' liked' : ''}`,
    `♡ ${post.likeCount || 0}`,
  );
  like.type = 'button';
  like.setAttribute('aria-label', post.liked ? 'Unlike post' : 'Like post');
  like.addEventListener('click', async () => {
    if (!currentUser) return (location.href = '/login');
    const wasLiked = Boolean(post.liked);
    post.liked = !wasLiked;
    post.likeCount = Math.max(0, Number(post.likeCount) + (wasLiked ? -1 : 1));
    like.classList.toggle('liked', post.liked);
    like.textContent = `${post.liked ? '♥' : '♡'} ${post.likeCount}`;
    try {
      const result = await api(`/posts/${post.id}/likes`, json({}));
      post.liked = result.liked;
      post.likeCount = result.likeCount;
      like.classList.toggle('liked', post.liked);
      like.textContent = `${post.liked ? '♥' : '♡'} ${post.likeCount}`;
    } catch (error) {
      post.liked = wasLiked;
      post.likeCount = Math.max(0, post.likeCount + (wasLiked ? 1 : -1));
      like.classList.toggle('liked', wasLiked);
      like.textContent = `${wasLiked ? '♥' : '♡'} ${post.likeCount}`;
      toast(error.message, 'error');
    }
  });
  const comment = document.createElement('a');
  comment.className = 'post-action';
  comment.href = `/post/${post.id}`;
  comment.textContent = `↩ ${post.commentCount || 0}`;
  const replyToggle = text('button', 'post-action inline-reply-toggle', 'Reply');
  replyToggle.type = 'button';
  const inline = document.createElement('section');
  inline.className = 'inline-comments';
  inline.hidden = true;
  let inlineLoaded = false;
  const appendInlineComment = (reply) => {
    const row = document.createElement('article');
    row.className = 'inline-comment';
    row.append(avatarLink(reply, 'sm'));
    const copy = document.createElement('div');
    copy.className = 'inline-comment-copy';
    const authorLink = document.createElement('a');
    authorLink.href = `/u/${encodeURIComponent(reply.username)}`;
    authorLink.textContent = reply.displayName;
    copy.append(authorLink, text('p', '', reply.content));
    if (currentUser?.id === reply.userId) {
      const remove = iconButton('Delete reply', '×', 'post-menu');
      remove.addEventListener('click', async () => {
        if (!window.confirm('Delete this reply?')) return;
        try {
          await api(`/comments/${reply.id}`, { method: 'DELETE' });
          row.remove();
          post.commentCount = Math.max(0, post.commentCount - 1);
          comment.textContent = `↩ ${post.commentCount}`;
        } catch (error) {
          toast(error.message, 'error');
        }
      });
      copy.append(remove);
    }
    row.append(copy);
    inline.prepend(row);
  };
  replyToggle.addEventListener('click', async () => {
    if (!currentUser)
      return (location.href = `/login?next=${encodeURIComponent(location.pathname)}`);
    inline.hidden = !inline.hidden;
    if (inline.hidden || inlineLoaded) return;
    inlineLoaded = true;
    try {
      const { comments } = await api(`/posts/${post.id}/comments`);
      const form = document.createElement('form');
      form.className = 'inline-reply-form';
      const input = document.createElement('input');
      input.name = 'content';
      input.maxLength = 280;
      input.required = true;
      input.placeholder = 'Add a thoughtful reply…';
      input.setAttribute('aria-label', 'Add a reply');
      const submit = text('button', 'primary-button', 'Reply');
      submit.type = 'submit';
      form.append(input, submit);
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        submit.disabled = true;
        try {
          const { comment: created } = await api(
            `/posts/${post.id}/comments`,
            json({ content: input.value.trim() }),
          );
          appendInlineComment(created);
          input.value = '';
          post.commentCount = Number(post.commentCount || 0) + 1;
          comment.textContent = `↩ ${post.commentCount}`;
        } catch (error) {
          toast(error.message, 'error');
        } finally {
          submit.disabled = false;
        }
      });
      inline.append(form);
      comments.forEach(appendInlineComment);
      if (!comments.length)
        inline.prepend(text('p', 'inline-empty', 'No replies yet. Start the conversation.'));
      input.focus();
    } catch (error) {
      toast(error.message, 'error');
      inlineLoaded = false;
    }
  });
  actions.append(like, comment, replyToggle);
  card.append(header, body);
  if (media.childElementCount) card.append(media);
  card.append(actions, inline);
  return card;
}

export function followButton(user, { onChange } = {}) {
  const button = text(
    'button',
    `follow-button${user.followedByMe ? ' following' : ''}`,
    user.followedByMe ? 'Following' : 'Follow',
  );
  button.type = 'button';
  button.addEventListener('click', async () => {
    if (!currentUser) return (location.href = '/login');
    const before = Boolean(user.followedByMe);
    user.followedByMe = !before;
    button.classList.toggle('following', user.followedByMe);
    button.textContent = user.followedByMe ? 'Following' : 'Follow';
    button.disabled = true;
    try {
      const result = await api(`/users/${encodeURIComponent(user.username)}/follow`, json({}));
      user.followedByMe = result.following;
      user.followerCount = result.followerCount;
      button.classList.toggle('following', user.followedByMe);
      button.textContent = user.followedByMe ? 'Following' : 'Follow';
      onChange?.(user);
    } catch (error) {
      user.followedByMe = before;
      button.classList.toggle('following', before);
      button.textContent = before ? 'Following' : 'Follow';
      toast(error.message, 'error');
    } finally {
      button.disabled = false;
    }
  });
  return button;
}

export function personRow(user, options = {}) {
  const row = document.createElement('article');
  row.className = 'person-row';
  row.append(avatarLink(user, 'md'));
  const info = document.createElement('a');
  info.className = 'person-copy';
  info.href = `/u/${encodeURIComponent(user.username)}`;
  info.append(text('strong', '', user.displayName), text('span', '', `@${user.username}`));
  if (user.bio) info.append(text('p', '', user.bio));
  row.append(info);
  if (currentUser?.id !== user.id) row.append(followButton(user, options));
  return row;
}

export async function initShell({ protectedPage = false, authPage = false } = {}) {
  document.documentElement.dataset.theme = localStorage.getItem('kenny-theme') || 'light';
  try {
    currentUser = (await api('/auth/me')).user;
  } catch {
    currentUser = null;
  }
  if (protectedPage && !currentUser) {
    location.replace(`/login?next=${encodeURIComponent(location.pathname + location.search)}`);
    return null;
  }
  if (authPage && currentUser) {
    location.replace('/');
    return currentUser;
  }
  const counts = { notifications: 0, messages: 0 };
  if (currentUser) {
    const [notifications, messages] = await Promise.allSettled([
      api('/notifications'),
      api('/messages'),
    ]);
    if (notifications.status === 'fulfilled')
      counts.notifications = notifications.value.unreadCount;
    if (messages.status === 'fulfilled')
      counts.messages = messages.value.conversations.reduce(
        (sum, item) => sum + item.unreadCount,
        0,
      );
  }
  renderHeader();
  renderNavigation(counts);
  const rail = $('#right-rail');
  if (rail) {
    rail.innerHTML =
      '<section class="side-section welcome-note"><div class="section-kicker"><span class="kicker-dot"></span> A quieter corner</div><h2>Good things<br>travel by word.</h2><p>Follow a few people. Stay for the little things.</p><a class="text-link" href="/explore">Explore the feed ↗</a></section><section class="side-section"><h2 class="section-title">People to know</h2><div id="shell-suggestions" class="suggested-list"></div></section><footer class="side-footer">Made for the small moments.</footer>';
    try {
      const { users } = await api('/users/suggestions');
      const target = $('#shell-suggestions');
      if (users.length) users.slice(0, 4).forEach((user) => target.append(personRow(user)));
      else target.append(text('p', 'side-loading', 'You’re all caught up.'));
    } catch {
      /* Suggestions are optional shell content. */
    }
  }
  return currentUser;
}

export function emptyState(title, message) {
  const section = document.createElement('section');
  section.className = 'empty-state';
  section.append(
    text('div', 'empty-illustration', 'k'),
    text('h2', '', title),
    text('p', '', message),
  );
  return section;
}

export function bindSearchShortcut() {
  document.addEventListener('keydown', (event) => {
    if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
      event.preventDefault();
      $('.header-search input')?.focus();
    }
  });
}

export function profileFromPath() {
  return decodeURIComponent(location.pathname.split('/').filter(Boolean).at(-1) || '');
}

export function initTheme() {
  document.addEventListener('click', (event) => {
    if (event.target.closest('.theme-toggle')) toggleTheme();
  });
}

export function clearUnreadBadge(key) {
  document
    .querySelectorAll(`[data-nav-key="${key}"] .nav-badge`)
    .forEach((badge) => badge.remove());
}

initTheme();
bindSearchShortcut();
