@echo off
setlocal

set "APP_DIR=%~dp0"
set "NODE_EXE=%LOCALAPPDATA%\ChirpNode\node-v22.23.3-win-x64\node.exe"
set "APP_URL=http://localhost:3000"

if not exist "%NODE_EXE%" (
  for %%N in (node.exe) do set "NODE_EXE=%%~$PATH:N"
)

if not exist "%NODE_EXE%" (
  echo Node.js was not found. Install Node.js 18 or newer, then run this file again.
  pause
  exit /b 1
)

pushd "%APP_DIR%"
powershell -NoProfile -Command "try { Invoke-WebRequest -Uri '%APP_URL%' -UseBasicParsing -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }"
if errorlevel 1 (
  start "Kenny on Chirp server" cmd /k "cd /d ""%APP_DIR%"" ^&^& ""%NODE_EXE%"" server.js"
  timeout /t 2 /nobreak >nul
)

start "" "%APP_URL%"
popd
endlocal
