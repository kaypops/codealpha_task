require('dotenv').config();

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error('Set JWT_SECRET to a random string of at least 32 characters in .env.');
}

const path = require('node:path');
const express = require('express');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const authRoutes = require('./server/routes/auth');
const socialRoutes = require('./server/routes/social');
const { notFound, errorHandler } = require('./server/middleware/errors');

const app = express();
const port = Number(process.env.PORT) || 3000;

app.disable('x-powered-by');
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        mediaSrc: ["'self'", 'blob:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
      },
    },
  }),
);
app.use(
  cors({ origin: process.env.CLIENT_ORIGIN || `http://localhost:${port}`, credentials: true }),
);
app.use(express.json({ limit: '16kb' }));
app.use(cookieParser());
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 300,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
  }),
);
app.use('/api/auth', authRoutes);
app.use('/api', socialRoutes);
const page = (filename) => (_req, res) => res.sendFile(path.join(__dirname, 'public', filename));
app.get('/', page('index.html'));
app.get('/index.html', page('index.html'));
app.get('/welcome', (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/root.css', (_req, res) => res.sendFile(path.join(__dirname, 'root.css')));
app.get('/login', page('login.html'));
app.get('/register', page('register.html'));
app.get('/explore', page('explore.html'));
app.get('/post/:id', page('post.html'));
app.get('/u/:username/followers', page('followers.html'));
app.get('/u/:username/following', page('following.html'));
app.get('/u/:username', page('profile.html'));
app.get('/notifications', page('notifications.html'));
app.get('/messages', page('messages.html'));
app.get('/messages/:username', page('messages.html'));
app.get('/settings', page('settings.html'));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));
app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) return notFound(req, res, next);
  return res.status(404).sendFile(path.join(__dirname, 'public/404.html'));
});
app.use(errorHandler);

if (require.main === module) {
  app.listen(port, () => console.log(`Kenny on Chirp is ready at http://localhost:${port}`));
}

module.exports = app;
