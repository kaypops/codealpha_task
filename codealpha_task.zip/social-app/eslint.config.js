const js = require('@eslint/js');
const globals = require('globals');

module.exports = [
  { ignores: ['node_modules/**', 'server/db/*.sqlite'] },
  js.configs.recommended,
  {
    files: ['server.js', 'server/**/*.js', 'test/**/*.js'],
    languageOptions: { globals: { ...globals.node, ...globals.commonjs } },
  },
  {
    files: ['eslint.config.js'],
    languageOptions: { globals: { ...globals.node, ...globals.commonjs } },
  },
  {
    files: ['scripts/**/*.js'],
    languageOptions: { globals: { ...globals.node, ...globals.commonjs } },
  },
  {
    files: ['public/js/**/*.js'],
    languageOptions: { sourceType: 'module', globals: { ...globals.browser } },
  },
  {
    rules: {
      'no-unused-vars': ['error', { argsIgnorePattern: '^_', caughtErrorsIgnorePattern: '^_' }],
    },
  },
];
