const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { after, before, test } = require('node:test');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kenny-chirp-test-'));
process.env.DB_PATH = path.join(tempDir, 'test.sqlite');
process.env.JWT_SECRET = 'test-only-secret-that-is-at-least-32-characters-long';

const app = require('../server');
const db = require('../server/db/database');
let server;
let baseUrl;

before(async () => {
  server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}/api`;
});

after(async () => {
  await new Promise((resolve, reject) =>
    server.close((error) => (error ? reject(error) : resolve())),
  );
  db.close();
  fs.rmSync(tempDir, { recursive: true, force: true });
});

test('auth and social API supports the complete post-to-follow flow', async () => {
  let cookie = '';
  const request = async (url, options = {}) => {
    const { cookie: requestCookie, ...fetchOptions } = options;
    return fetch(`${baseUrl}${url}`, {
      ...fetchOptions,
      headers: {
        ...(fetchOptions.body && !(fetchOptions.body instanceof FormData)
          ? { 'content-type': 'application/json' }
          : {}),
        ...(requestCookie || cookie ? { cookie: requestCookie || cookie } : {}),
        ...fetchOptions.headers,
      },
    });
  };
  const saveCookie = (response) => {
    const token = response.headers.get('set-cookie')?.match(/token=[^;]+/)?.[0];
    if (token) cookie = token;
  };

  let response = await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      username: 'kenny',
      email: 'kenny@example.test',
      password: 'password123',
      displayName: 'Kenny Brooks',
    }),
  });
  assert.equal(response.status, 201);
  saveCookie(response);
  const { user: kenny } = await response.json();
  assert.equal(kenny.username, 'kenny');

  response = await request('/auth/me');
  assert.equal(response.status, 200);
  assert.equal((await response.json()).user.id, kenny.id);
  response = await request('/users/kenny/follow', { method: 'POST', body: '{}' });
  assert.equal(response.status, 400);

  response = await request('/posts', {
    method: 'POST',
    body: JSON.stringify({ content: 'A good little thought.' }),
  });
  assert.equal(response.status, 201);
  const { post } = await response.json();

  const mediaForm = new FormData();
  mediaForm.set('content', 'A photo status from the integration flow.');
  mediaForm.append(
    'media',
    new Blob(
      [
        Buffer.from(
          'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/FioAAAAASUVORK5CYII=',
          'base64',
        ),
      ],
      { type: 'image/png' },
    ),
    'tiny.png',
  );
  response = await request('/posts', { method: 'POST', body: mediaForm });
  assert.equal(response.status, 201);
  const { post: mediaPost } = await response.json();
  assert.equal(mediaPost.media.length, 1);
  assert.match(mediaPost.media[0].url, /^\/uploads\//);
  response = await fetch(new URL(mediaPost.media[0].url, baseUrl));
  assert.equal(response.status, 200);
  assert.equal(response.headers.get('content-type'), 'image/png');

  response = await request('/feed?limit=10&offset=0');
  assert.ok(
    (await response.json()).posts.some(
      (item) => item.id === post.id && item.content === post.content,
    ),
  );
  response = await request(`/posts/${post.id}`);
  assert.equal((await response.json()).post.id, post.id);

  response = await request(`/posts/${post.id}/likes`, { method: 'POST', body: '{}' });
  assert.deepEqual(await response.json(), { liked: true, likeCount: 1 });
  response = await request(`/posts/${post.id}/likes`, { method: 'POST', body: '{}' });
  assert.deepEqual(await response.json(), { liked: false, likeCount: 0 });

  response = await request(`/posts/${post.id}/comments`, {
    method: 'POST',
    body: JSON.stringify({ content: 'Nicely said.' }),
  });
  assert.equal(response.status, 201);
  const { comment } = await response.json();
  response = await request(`/posts/${post.id}/comments`);
  assert.equal((await response.json()).comments.length, 1);
  response = await request(`/comments/${comment.id}`, { method: 'DELETE' });
  assert.equal(response.status, 200);

  db.prepare(
    'INSERT INTO users (username, email, password_hash, display_name) VALUES (?, ?, ?, ?)',
  ).run('maya', 'maya@example.test', 'unused', 'Maya Chen');

  response = await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({
      username: 'sam',
      email: 'sam@example.test',
      password: 'password123',
      displayName: 'Sam Park',
    }),
  });
  assert.equal(response.status, 201);
  saveCookie(response);
  const samCookie = cookie;
  const samFollow = await request('/users/kenny/follow', {
    method: 'POST',
    body: '{}',
    cookie: samCookie,
  });
  assert.equal((await samFollow.json()).following, true);
  const samMessage = await request('/messages/kenny', {
    method: 'POST',
    body: JSON.stringify({ content: 'Hello from Sam.' }),
    cookie: samCookie,
  });
  assert.equal(samMessage.status, 201);
  const samLike = await request(`/posts/${post.id}/likes`, {
    method: 'POST',
    body: '{}',
    cookie: samCookie,
  });
  assert.equal((await samLike.json()).liked, true);
  const samComment = await request(`/posts/${post.id}/comments`, {
    method: 'POST',
    body: JSON.stringify({ content: 'A reply from Sam.' }),
    cookie: samCookie,
  });
  assert.equal(samComment.status, 201);

  const kennyCookie = (
    await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'kenny@example.test', password: 'password123' }),
    })
  ).headers
    .get('set-cookie')
    ?.match(/token=[^;]+/)?.[0];
  cookie = kennyCookie || '';

  response = await request('/users/maya/follow', { method: 'POST', body: '{}' });
  assert.deepEqual(await response.json(), { following: true, followerCount: 1 });
  response = await request('/users/kenny/following');
  assert.equal((await response.json()).users[0].username, 'maya');
  response = await request('/users/maya/followers');
  assert.equal((await response.json()).users[0].username, 'kenny');
  response = await request('/feed?type=following');
  assert.equal((await response.json()).posts.length, 0);

  response = await request('/users/me', {
    method: 'PATCH',
    body: JSON.stringify({ displayName: 'Kenny B.', bio: 'hello' }),
  });
  assert.equal((await response.json()).user.displayName, 'Kenny B.');
  response = await request('/users/kenny');
  assert.equal((await response.json()).user.bio, 'hello');
  response = await request('/users/suggestions');
  assert.equal(response.status, 200);

  response = await request(`/users/kenny/likes`);
  assert.equal(response.status, 200);
  response = await request('/search?q=thought');
  assert.equal(response.status, 200);
  assert.ok((await response.json()).posts.length);
  response = await request('/messages');
  const { conversations } = await response.json();
  assert.ok(conversations.some((item) => item.username === 'sam' && item.unreadCount === 1));
  response = await request('/messages/sam');
  assert.equal((await response.json()).messages.at(-1).content, 'Hello from Sam.');
  response = await request('/messages');
  assert.equal(
    (await response.json()).conversations.find((item) => item.username === 'sam').unreadCount,
    0,
  );
  response = await request('/notifications');
  const notificationData = await response.json();
  assert.ok(
    notificationData.notifications.some(
      (item) => item.type === 'follow' && item.actorUsername === 'sam',
    ),
  );
  assert.ok(
    notificationData.notifications.some(
      (item) => item.type === 'like' && item.actorUsername === 'sam',
    ),
  );
  assert.ok(
    notificationData.notifications.some(
      (item) => item.type === 'comment' && item.actorUsername === 'sam',
    ),
  );
  assert.equal(notificationData.notifications.length, 3);
  assert.ok(notificationData.unreadCount > 0);
  response = await request('/notifications/read', { method: 'POST' });
  assert.deepEqual(await response.json(), { unreadCount: 0 });

  const storyForm = new FormData();
  storyForm.set('content', 'A fleeting story from the integration flow.');
  storyForm.append(
    'media',
    new Blob(
      [
        Buffer.from(
          'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/FioAAAAASUVORK5CYII=',
          'base64',
        ),
      ],
      { type: 'image/png' },
    ),
    'story.png',
  );
  response = await request('/stories', { method: 'POST', body: storyForm });
  assert.equal(response.status, 201);
  const { story } = await response.json();
  assert.equal(story.mediaType, 'image');
  assert.ok(story.mediaUrl.startsWith('/uploads/'));
  assert.ok(
    new Date(story.expiresAt).getTime() - new Date(story.createdAt).getTime() >=
      23 * 60 * 60 * 1000,
  );
  response = await request('/stories');
  assert.ok((await response.json()).stories.some((item) => item.id === story.id));
  response = await request(`/stories/${story.id}/view`, { method: 'POST' });
  assert.equal(response.status, 200);
  response = await request(`/stories/${story.id}`, { method: 'DELETE' });
  assert.equal(response.status, 200);
  response = await request('/me/password', {
    method: 'PUT',
    body: JSON.stringify({ currentPassword: 'password123', newPassword: 'new-password-123' }),
  });
  assert.equal(response.status, 200);
  response = await request('/me', {
    method: 'PUT',
    body: JSON.stringify({ displayName: 'Kenny Updated', bio: 'hello again' }),
  });
  assert.equal((await response.json()).user.displayName, 'Kenny Updated');

  response = await request(`/posts/${post.id}`, { method: 'DELETE' });
  assert.equal(response.status, 200);
  response = await request(`/posts/${mediaPost.id}`, { method: 'DELETE' });
  assert.equal(response.status, 200);
  response = await request(`/posts/${post.id}`);
  assert.equal(response.status, 404);

  response = await request('/auth/logout', { method: 'POST' });
  assert.equal(response.status, 200);
  cookie = '';
  response = await request('/auth/me');
  assert.equal(response.status, 401);
});

test('clean page routes serve their pages and unknown paths use the styled 404', async () => {
  const origin = baseUrl.replace(/\/api$/, '');
  const routes = [
    '/',
    '/login',
    '/register',
    '/explore',
    '/post/1',
    '/u/kenny',
    '/u/kenny/followers',
    '/u/kenny/following',
    '/notifications',
    '/messages',
    '/messages/maya',
    '/settings',
    '/welcome',
    '/root.css',
  ];
  for (const route of routes) {
    const response = await fetch(`${origin}${route}`);
    assert.equal(response.status, 200, `${route} should be served`);
  }
  const missing = await fetch(`${origin}/definitely-not-a-page`);
  assert.equal(missing.status, 404);
  assert.match(await missing.text(), /Page not found|NOT FOUND|404/i);
});
