function notFound(_req, res) {
  res.status(404).json({ error: 'That endpoint could not be found.' });
}

function errorHandler(error, _req, res, _next) {
  if (error.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'Each image or video must be 20 MB or smaller.' });
  }
  if (error.code === 'LIMIT_FILE_COUNT' || error.code === 'LIMIT_UNEXPECTED_FILE') {
    return res.status(400).json({
      error: 'A status can include up to four images or videos; a Story can include one.',
    });
  }
  if (error.message?.startsWith('Upload a supported')) {
    return res.status(400).json({ error: error.message });
  }
  if (error.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Please send valid JSON.' });
  }
  if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
    return res.status(409).json({ error: 'That username or email is already in use.' });
  }
  console.error(error);
  return res.status(500).json({ error: 'Something went wrong. Please try again.' });
}

module.exports = { notFound, errorHandler };
