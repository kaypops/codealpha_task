const jwt = require('jsonwebtoken');

function getToken(req) {
  return req.cookies?.token || req.get('authorization')?.replace(/^Bearer\s+/i, '');
}

function optionalAuth(req, _res, next) {
  const token = getToken(req);
  if (token) {
    try {
      req.user = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      req.user = null;
    }
  }
  next();
}

function requireAuth(req, res, next) {
  const token = getToken(req);
  if (!token) return res.status(401).json({ error: 'Please sign in to continue.' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
  }
}

module.exports = { optionalAuth, requireAuth };
