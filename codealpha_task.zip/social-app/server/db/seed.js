require('dotenv').config();

const bcrypt = require('bcrypt');
const db = require('./database');

const demoPasswordHash = bcrypt.hashSync('kenny-demo', 10);
const demoUsers = [
  {
    username: 'kenny',
    email: 'kenny@chirp.local',
    name: 'Kenny Brooks',
    bio: 'Building small things with a little more heart.',
  },
  {
    username: 'maya',
    email: 'maya@chirp.local',
    name: 'Maya Chen',
    bio: 'Design systems, good coffee, better questions.',
  },
  {
    username: 'leo',
    email: 'leo@chirp.local',
    name: 'Leo Martin',
    bio: 'Frontend craft and weekend trail miles.',
  },
  {
    username: 'noa',
    email: 'noa@chirp.local',
    name: 'Noa Rivera',
    bio: 'Making the internet feel a bit more human.',
  },
  {
    username: 'imani',
    email: 'imani@chirp.local',
    name: 'Imani Cole',
    bio: 'Collecting good questions and Sunday recipes.',
  },
  {
    username: 'felix',
    email: 'felix@chirp.local',
    name: 'Felix Park',
    bio: 'A curious mind, usually near a camera.',
  },
];

const demoPosts = [
  ['kenny', 'A tiny reminder: the best products feel like someone paid attention.'],
  [
    'maya',
    'Spent the morning removing one unnecessary step from a flow. It feels lighter already.',
  ],
  ['leo', 'A good empty state is a small act of hospitality.'],
  ['noa', 'What is one detail in an app that made you smile this week?'],
  ['kenny', 'A useful test for a feature: does it make someone feel more welcome?'],
  ['maya', 'Today I learned that the best critique starts with a real question.'],
  ['leo', 'A tiny refactor can make the whole afternoon feel calmer.'],
  ['noa', 'Leave a little room in the plan for something unexpected.'],
  ['imani', 'The group chat recipe swap remains undefeated.'],
  ['felix', 'Golden hour is generous with everyone.'],
  ['kenny', 'What is something small you are looking forward to this week?'],
  ['maya', 'Made a button softer and somehow the whole page exhaled.'],
  ['leo', 'The first draft only has to exist.'],
  ['noa', 'A note to future me: go outside before the second coffee.'],
  ['imani', 'A good playlist is a kind of architecture.'],
  ['felix', 'Found a quiet street with very loud flowers.'],
  ['kenny', 'A thoughtful reply can turn a post into a conversation.'],
  ['maya', 'Keeping the little details consistent is a love language.'],
  ['leo', 'Shipped it, closed the laptop, took the long way home.'],
  ['noa', 'Tell someone specifically what you appreciate about them today.'],
];

const seed = db.transaction(() => {
  const insertUser = db.prepare(`
    INSERT OR IGNORE INTO users (username, email, password_hash, display_name, bio)
    VALUES (@username, @email, @passwordHash, @name, @bio)
  `);
  for (const user of demoUsers) {
    insertUser.run({ ...user, passwordHash: demoPasswordHash });
  }

  const userIds = Object.fromEntries(
    demoUsers.map(({ username }) => [
      username,
      db.prepare('SELECT id FROM users WHERE username = ?').get(username).id,
    ]),
  );

  const insertPost = db.prepare(`
    INSERT INTO posts (user_id, content)
    SELECT ?, ?
    WHERE NOT EXISTS (
      SELECT 1 FROM posts WHERE user_id = ? AND content = ?
    )
  `);
  for (const [username, content] of demoPosts) {
    insertPost.run(userIds[username], content, userIds[username], content);
  }

  const kennyPost = db
    .prepare('SELECT id FROM posts WHERE user_id = ? ORDER BY id LIMIT 1')
    .get(userIds.kenny);
  const mayaPost = db
    .prepare('SELECT id FROM posts WHERE user_id = ? ORDER BY id LIMIT 1')
    .get(userIds.maya);
  const insertComment = db.prepare(`
    INSERT INTO comments (post_id, user_id, content)
    SELECT ?, ?, ?
    WHERE NOT EXISTS (
      SELECT 1 FROM comments WHERE post_id = ? AND user_id = ? AND content = ?
    )
  `);
  insertComment.run(
    kennyPost.id,
    userIds.maya,
    'This is such a good north star.',
    kennyPost.id,
    userIds.maya,
    'This is such a good north star.',
  );
  insertComment.run(
    mayaPost.id,
    userIds.kenny,
    'Tiny improvements add up.',
    mayaPost.id,
    userIds.kenny,
    'Tiny improvements add up.',
  );

  const insertFollow = db.prepare(
    'INSERT OR IGNORE INTO follows (follower_id, following_id) VALUES (?, ?)',
  );
  insertFollow.run(userIds.kenny, userIds.maya);
  insertFollow.run(userIds.kenny, userIds.leo);
  insertFollow.run(userIds.maya, userIds.kenny);
  insertFollow.run(userIds.leo, userIds.kenny);
  insertFollow.run(userIds.noa, userIds.maya);
  insertFollow.run(userIds.imani, userIds.kenny);
  insertFollow.run(userIds.felix, userIds.leo);
  insertFollow.run(userIds.kenny, userIds.imani);
  insertFollow.run(userIds.maya, userIds.noa);

  const insertLike = db.prepare('INSERT OR IGNORE INTO likes (user_id, post_id) VALUES (?, ?)');
  insertLike.run(userIds.maya, kennyPost.id);
  insertLike.run(userIds.leo, kennyPost.id);

  const insertMessage = db.prepare(`
    INSERT INTO messages (sender_id, receiver_id, content, created_at, read_at)
    SELECT ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now', ?), ?
    WHERE NOT EXISTS (
      SELECT 1 FROM messages WHERE sender_id = ? AND receiver_id = ? AND content = ?
    )
  `);
  const conversations = [
    ['kenny', 'maya', 'I was thinking about that design question you shared.'],
    ['maya', 'kenny', 'Same here. Want to trade notes after lunch?'],
    ['kenny', 'maya', 'Absolutely. I will bring coffee.'],
    ['leo', 'kenny', 'That tiny refactor tip saved me a whole hour.'],
    ['kenny', 'leo', 'Glad it helped. Your empty-state post was spot on.'],
    ['noa', 'imani', 'Are you still bringing that playlist to the picnic?'],
    ['imani', 'noa', 'Already queued up. See you there!'],
  ];
  conversations.forEach(([from, to, content], index) => {
    insertMessage.run(
      userIds[from],
      userIds[to],
      content,
      `-${conversations.length - index} hours`,
      to === 'kenny' && from !== 'kenny' ? null : new Date().toISOString(),
      userIds[from],
      userIds[to],
      content,
    );
  });

  const insertNotification = db.prepare(`
    INSERT INTO notifications (user_id, actor_id, type, post_id)
    SELECT ?, ?, ?, ?
    WHERE NOT EXISTS (
      SELECT 1 FROM notifications WHERE user_id = ? AND actor_id = ? AND type = ? AND post_id IS ?
    )
  `);
  insertNotification.run(
    userIds.kenny,
    userIds.maya,
    'comment',
    kennyPost.id,
    userIds.kenny,
    userIds.maya,
    'comment',
    kennyPost.id,
  );

  const insertStory = db.prepare(`
    INSERT INTO stories (user_id, content)
    SELECT ?, ?
    WHERE NOT EXISTS (
      SELECT 1 FROM stories WHERE user_id = ? AND content = ?
        AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    )
  `);
  for (const [username, content] of [
    ['kenny', 'A fresh hello from Kenny.'],
    ['maya', 'Today: softer edges, stronger coffee.'],
    ['leo', 'A little sky between meetings.'],
    ['noa', 'Making room for good things.'],
    ['imani', 'Sunday recipe testing, early.'],
    ['felix', 'Found the light.'],
  ]) {
    insertStory.run(userIds[username], content, userIds[username], content);
  }
  insertNotification.run(
    userIds.kenny,
    userIds.leo,
    'like',
    kennyPost.id,
    userIds.kenny,
    userIds.leo,
    'like',
    kennyPost.id,
  );
  insertNotification.run(
    userIds.kenny,
    userIds.imani,
    'follow',
    null,
    userIds.kenny,
    userIds.imani,
    'follow',
    null,
  );
});

try {
  seed();
  const counts = {
    users: db.prepare('SELECT COUNT(*) AS count FROM users').get().count,
    posts: db.prepare('SELECT COUNT(*) AS count FROM posts').get().count,
    comments: db.prepare('SELECT COUNT(*) AS count FROM comments').get().count,
    follows: db.prepare('SELECT COUNT(*) AS count FROM follows').get().count,
    messages: db.prepare('SELECT COUNT(*) AS count FROM messages').get().count,
    activeStories: db
      .prepare(
        "SELECT COUNT(*) AS count FROM stories WHERE expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')",
      )
      .get().count,
  };
  console.log('Demo data is ready:', counts);
} finally {
  db.close();
}
