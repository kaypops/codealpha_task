const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const multer = require('multer');
const { body, param, query, validationResult } = require('express-validator');
const db = require('../db/database');
const { optionalAuth, requireAuth } = require('../middleware/auth');

const router = express.Router();
const uploadDirectory = path.join(__dirname, '..', '..', 'public', 'uploads');
fs.mkdirSync(uploadDirectory, { recursive: true });
const mediaTypes = new Map([
  ['image/jpeg', { type: 'image', extension: '.jpg' }],
  ['image/png', { type: 'image', extension: '.png' }],
  ['image/webp', { type: 'image', extension: '.webp' }],
  ['image/gif', { type: 'image', extension: '.gif' }],
  ['video/mp4', { type: 'video', extension: '.mp4' }],
  ['video/webm', { type: 'video', extension: '.webm' }],
  ['video/quicktime', { type: 'video', extension: '.mov' }],
]);
const mediaUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, callback) => callback(null, uploadDirectory),
    filename: (_req, file, callback) => {
      const kind = mediaTypes.get(file.mimetype);
      callback(null, `${randomUUID()}${kind?.extension || '.bin'}`);
    },
  }),
  limits: { fileSize: 20 * 1024 * 1024, files: 4 },
  fileFilter: (_req, file, callback) => {
    if (!mediaTypes.has(file.mimetype))
      return callback(new Error('Upload a supported JPG, PNG, WebP, GIF, MP4, WebM, or MOV file.'));
    return callback(null, true);
  },
});
const postSelect = `
  SELECT p.id, p.content, p.created_at AS createdAt,
    u.id AS userId, u.username, u.display_name AS displayName,
    (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS likeCount,
    (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS commentCount,
    EXISTS(SELECT 1 FROM likes l WHERE l.post_id = p.id AND l.user_id = ?) AS liked,
    (SELECT COALESCE(json_group_array(json_object(
      'url', pm.url, 'mediaType', pm.media_type, 'mimeType', pm.mime_type,
      'originalName', pm.original_name
    )), '[]') FROM post_media pm WHERE pm.post_id = p.id ORDER BY pm.position) AS media
  FROM posts p JOIN users u ON u.id = p.user_id
`;

function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    removeFiles([...(req.files || []), ...(req.file ? [req.file] : [])]);
    return res.status(400).json({ error: errors.array()[0].msg });
  }
  next();
}

function profileByUsername(username, viewerId = 0) {
  return db
    .prepare(
      `
    SELECT u.id, u.username, u.display_name AS displayName, u.bio, u.created_at AS createdAt,
      (SELECT COUNT(*) FROM posts WHERE user_id = u.id) AS postCount,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount,
      (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS followingCount,
      EXISTS(SELECT 1 FROM follows WHERE follower_id = ? AND following_id = u.id) AS followedByMe
    FROM users u WHERE u.username = ?
  `,
    )
    .get(viewerId, username);
}

function notify(userId, actorId, type, postId = null) {
  if (userId && userId !== actorId) {
    db.prepare(
      'INSERT INTO notifications (user_id, actor_id, type, post_id) VALUES (?, ?, ?, ?)',
    ).run(userId, actorId, type, postId);
  }
}

function normalizePost(post) {
  if (post && typeof post.media === 'string') {
    try {
      post.media = JSON.parse(post.media);
    } catch {
      post.media = [];
    }
  }
  return post;
}

function savePostMedia(postId, files = []) {
  const insert = db.prepare(`
    INSERT INTO post_media (post_id, url, media_type, mime_type, original_name, position)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  files.forEach((file, index) => {
    const kind = mediaTypes.get(file.mimetype);
    insert.run(
      postId,
      `/uploads/${file.filename}`,
      kind.type,
      file.mimetype,
      file.originalname.slice(0, 180),
      index,
    );
  });
}

function removeFiles(files = []) {
  files.forEach((file) => fs.promises.unlink(file.path).catch(() => {}));
}

router.get(
  '/feed',
  optionalAuth,
  [
    query('limit').optional().isInt({ min: 1, max: 50 }).toInt(),
    query('offset').optional().isInt({ min: 0 }).toInt(),
  ],
  validate,
  (req, res) => {
    const limit = req.query.limit || 20;
    const offset = req.query.offset || 0;
    const followingOnly = req.query.type === 'following';
    if (followingOnly && !req.user)
      return res.status(401).json({ error: 'Sign in to see your Following feed.' });
    const feedQuery = followingOnly
      ? `${postSelect} JOIN follows f ON f.following_id = p.user_id AND f.follower_id = ? ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?`
      : `${postSelect} ORDER BY p.created_at DESC, p.id DESC LIMIT ? OFFSET ?`;
    const params = followingOnly
      ? [req.user?.id || 0, req.user.id, limit, offset]
      : [req.user?.id || 0, limit, offset];
    const posts = db
      .prepare(feedQuery)
      .all(...params)
      .map(normalizePost);
    return res.json({ posts, limit, offset });
  },
);

router.post(
  '/posts',
  requireAuth,
  mediaUpload.array('media', 4),
  [
    body('content')
      .isString()
      .trim()
      .isLength({ min: 1, max: 280 })
      .withMessage('Posts must be between 1 and 280 characters.'),
  ],
  validate,
  (req, res) => {
    const files = req.files || [];
    if (!req.body.content?.trim()) {
      removeFiles(files);
      return res.status(400).json({ error: 'Add a short caption to your status update.' });
    }
    let postId;
    try {
      postId = db.transaction(() => {
        const result = db
          .prepare('INSERT INTO posts (user_id, content) VALUES (?, ?)')
          .run(req.user.id, req.body.content.trim());
        savePostMedia(result.lastInsertRowid, files);
        return result.lastInsertRowid;
      })();
    } catch (error) {
      removeFiles(files);
      throw error;
    }
    const post = normalizePost(db.prepare(`${postSelect} WHERE p.id = ?`).get(req.user.id, postId));
    return res.status(201).json({ post });
  },
);

router.get(
  '/posts/:id',
  optionalAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    const post = normalizePost(
      db.prepare(`${postSelect} WHERE p.id = ?`).get(req.user?.id || 0, req.params.id),
    );
    if (!post) return res.status(404).json({ error: 'That post could not be found.' });
    const comments = db
      .prepare(
        `
    SELECT c.id, c.content, c.created_at AS createdAt, u.id AS userId,
      u.username, u.display_name AS displayName
    FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.post_id = ? ORDER BY c.created_at, c.id
  `,
      )
      .all(post.id);
    return res.json({ post, comments });
  },
);

router.delete(
  '/posts/:id',
  requireAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    const media = db.prepare('SELECT url FROM post_media WHERE post_id = ?').all(req.params.id);
    const result = db
      .prepare('DELETE FROM posts WHERE id = ? AND user_id = ?')
      .run(req.params.id, req.user.id);
    if (!result.changes)
      return res
        .status(404)
        .json({ error: 'That post could not be found or does not belong to you.' });
    media.forEach((item) => {
      fs.promises.unlink(path.join(uploadDirectory, path.basename(item.url))).catch(() => {});
    });
    return res.json({ message: 'Post deleted.' });
  },
);

router.post(
  '/posts/:id/likes',
  requireAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    if (!db.prepare('SELECT 1 FROM posts WHERE id = ?').get(req.params.id))
      return res.status(404).json({ error: 'That post could not be found.' });
    const existing = db
      .prepare('SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?')
      .get(req.user.id, req.params.id);
    if (existing) {
      db.prepare('DELETE FROM likes WHERE user_id = ? AND post_id = ?').run(
        req.user.id,
        req.params.id,
      );
    } else {
      db.prepare('INSERT INTO likes (user_id, post_id) VALUES (?, ?)').run(
        req.user.id,
        req.params.id,
      );
      const owner = db.prepare('SELECT user_id FROM posts WHERE id = ?').get(req.params.id);
      notify(owner?.user_id, req.user.id, 'like', Number(req.params.id));
    }
    const likeCount = db
      .prepare('SELECT COUNT(*) AS count FROM likes WHERE post_id = ?')
      .get(req.params.id).count;
    return res.json({ liked: !existing, likeCount });
  },
);

router.get('/posts/:id/comments', [param('id').isInt({ min: 1 }).toInt()], validate, (req, res) => {
  if (!db.prepare('SELECT 1 FROM posts WHERE id = ?').get(req.params.id))
    return res.status(404).json({ error: 'That post could not be found.' });
  const comments = db
    .prepare(
      `
    SELECT c.id, c.content, c.created_at AS createdAt, u.id AS userId,
      u.username, u.display_name AS displayName
    FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.post_id = ? ORDER BY c.created_at, c.id
  `,
    )
    .all(req.params.id);
  return res.json({ comments });
});

router.post(
  '/posts/:id/comments',
  requireAuth,
  [
    param('id').isInt({ min: 1 }).toInt(),
    body('content')
      .isString()
      .trim()
      .isLength({ min: 1, max: 280 })
      .withMessage('Comments must be between 1 and 280 characters.'),
  ],
  validate,
  (req, res) => {
    if (!db.prepare('SELECT 1 FROM posts WHERE id = ?').get(req.params.id))
      return res.status(404).json({ error: 'That post could not be found.' });
    const result = db
      .prepare('INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)')
      .run(req.params.id, req.user.id, req.body.content);
    const owner = db.prepare('SELECT user_id FROM posts WHERE id = ?').get(req.params.id);
    notify(owner?.user_id, req.user.id, 'comment', Number(req.params.id));
    const comment = db
      .prepare(
        `
    SELECT c.id, c.content, c.created_at AS createdAt, u.id AS userId,
      u.username, u.display_name AS displayName
    FROM comments c JOIN users u ON u.id = c.user_id WHERE c.id = ?
  `,
      )
      .get(result.lastInsertRowid);
    return res.status(201).json({ comment });
  },
);

router.delete(
  '/comments/:id',
  requireAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    const result = db
      .prepare('DELETE FROM comments WHERE id = ? AND user_id = ?')
      .run(req.params.id, req.user.id);
    if (!result.changes)
      return res
        .status(404)
        .json({ error: 'That comment could not be found or does not belong to you.' });
    return res.json({ message: 'Comment deleted.' });
  },
);

router.get(
  '/search',
  optionalAuth,
  [query('q').optional().trim().isLength({ max: 80 })],
  validate,
  (req, res) => {
    const term = String(req.query.q || '').trim();
    if (!term) return res.json({ users: [], posts: [] });
    const pattern = `%${term.replace(/[\\%_]/g, '\\$&')}%`;
    const users = db
      .prepare(
        `
    SELECT u.username, u.display_name AS displayName, u.bio,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount
    FROM users u WHERE u.username LIKE ? ESCAPE '\\' OR u.display_name LIKE ? ESCAPE '\\'
    ORDER BY followerCount DESC, u.username LIMIT 10
  `,
      )
      .all(pattern, pattern);
    const posts = db
      .prepare(
        `${postSelect} WHERE p.content LIKE ? ESCAPE '\\' ORDER BY p.created_at DESC, p.id DESC LIMIT 20`,
      )
      .all(req.user?.id || 0, pattern)
      .map(normalizePost);
    return res.json({ users, posts });
  },
);

router.get('/stories', requireAuth, (_req, res) => {
  const stories = db
    .prepare(
      `
    SELECT s.id, s.content, s.media_url AS mediaUrl, s.media_type AS mediaType,
      s.mime_type AS mimeType, s.created_at AS createdAt, s.expires_at AS expiresAt,
      u.id AS userId, u.username, u.display_name AS displayName,
      EXISTS(SELECT 1 FROM story_views v WHERE v.story_id = s.id AND v.user_id = @viewerId) AS viewed,
      (SELECT COUNT(*) FROM story_views v WHERE v.story_id = s.id) AS viewCount
    FROM stories s JOIN users u ON u.id = s.user_id
    WHERE s.expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      AND (s.user_id = @viewerId OR EXISTS(
        SELECT 1 FROM follows f WHERE f.follower_id = @viewerId AND f.following_id = s.user_id
      ))
    ORDER BY (s.user_id = @viewerId) DESC, s.created_at DESC, s.id DESC
  `,
    )
    .all({ viewerId: _req.user.id });
  return res.json({ stories });
});

router.post(
  '/stories',
  requireAuth,
  mediaUpload.single('media'),
  [body('content').optional().trim().isLength({ max: 280 })],
  validate,
  (req, res) => {
    const file = req.file;
    const content = String(req.body.content || '').trim();
    if (!content && !file)
      return res.status(400).json({ error: 'Add a note or media to your Story.' });
    const type = file ? mediaTypes.get(file.mimetype).type : null;
    const result = db
      .prepare(
        `
      INSERT INTO stories (user_id, content, media_url, media_type, mime_type, original_name)
      VALUES (?, ?, ?, ?, ?, ?)
    `,
      )
      .run(
        req.user.id,
        content,
        file ? `/uploads/${file.filename}` : null,
        type,
        file?.mimetype || null,
        file?.originalname.slice(0, 180) || null,
      );
    const story = db
      .prepare(
        `
      SELECT s.id, s.content, s.media_url AS mediaUrl, s.media_type AS mediaType,
        s.mime_type AS mimeType, s.created_at AS createdAt, s.expires_at AS expiresAt,
        u.id AS userId, u.username, u.display_name AS displayName, 0 AS viewed, 0 AS viewCount
      FROM stories s JOIN users u ON u.id = s.user_id WHERE s.id = ?
    `,
      )
      .get(result.lastInsertRowid);
    return res.status(201).json({ story });
  },
);

router.post(
  '/stories/:id/view',
  requireAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    const story = db
      .prepare(
        `
    SELECT id FROM stories WHERE id = ? AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
  `,
      )
      .get(req.params.id);
    if (!story)
      return res.status(404).json({ error: 'That Story has expired or could not be found.' });
    db.prepare('INSERT OR IGNORE INTO story_views (story_id, user_id) VALUES (?, ?)').run(
      story.id,
      req.user.id,
    );
    return res.json({ viewed: true });
  },
);

router.delete(
  '/stories/:id',
  requireAuth,
  [param('id').isInt({ min: 1 }).toInt()],
  validate,
  (req, res) => {
    const story = db
      .prepare('SELECT media_url AS mediaUrl FROM stories WHERE id = ? AND user_id = ?')
      .get(req.params.id, req.user.id);
    if (!story)
      return res
        .status(404)
        .json({ error: 'That Story could not be found or does not belong to you.' });
    db.prepare('DELETE FROM stories WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    if (story.mediaUrl)
      fs.promises.unlink(path.join(uploadDirectory, path.basename(story.mediaUrl))).catch(() => {});
    return res.json({ message: 'Story deleted.' });
  },
);

router.get('/users/suggestions', optionalAuth, (req, res) => {
  const viewerId = req.user?.id || 0;
  const users = db
    .prepare(
      `
    SELECT u.username, u.display_name AS displayName, u.bio,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount
    FROM users u
    WHERE u.id != ? AND NOT EXISTS (
      SELECT 1 FROM follows WHERE follower_id = ? AND following_id = u.id
    )
    ORDER BY followerCount DESC, u.username LIMIT 5
  `,
    )
    .all(viewerId, viewerId);
  return res.json({ users });
});

router.get('/users/:username', optionalAuth, (req, res) => {
  const user = profileByUsername(req.params.username, req.user?.id || 0);
  if (!user) return res.status(404).json({ error: 'That profile could not be found.' });
  const posts = db
    .prepare(`${postSelect} WHERE p.user_id = ? ORDER BY p.created_at DESC, p.id DESC LIMIT 50`)
    .all(req.user?.id || 0, user.id)
    .map(normalizePost);
  return res.json({ user, posts });
});

router.get('/users/:username/likes', optionalAuth, (req, res) => {
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username);
  if (!user) return res.status(404).json({ error: 'That profile could not be found.' });
  const posts = db
    .prepare(
      `
    ${postSelect.replace('FROM posts p JOIN users u ON u.id = p.user_id', 'FROM likes mine JOIN posts p ON p.id = mine.post_id JOIN users u ON u.id = p.user_id')}
    WHERE mine.user_id = ? ORDER BY mine.created_at DESC, p.id DESC LIMIT 50
  `,
    )
    .all(req.user?.id || 0, user.id)
    .map(normalizePost);
  return res.json({ posts });
});

router.patch(
  '/users/me',
  requireAuth,
  [
    body('displayName')
      .optional()
      .trim()
      .isLength({ min: 1, max: 40 })
      .withMessage('Display name must be 1–40 characters.'),
    body('bio')
      .optional()
      .trim()
      .isLength({ max: 160 })
      .withMessage('Bio must be 160 characters or fewer.'),
  ],
  validate,
  (req, res) => {
    const { displayName, bio } = req.body;
    if (displayName === undefined && bio === undefined)
      return res.status(400).json({ error: 'Add a display name or bio to update.' });
    db.prepare(
      'UPDATE users SET display_name = COALESCE(?, display_name), bio = COALESCE(?, bio) WHERE id = ?',
    ).run(displayName ?? null, bio ?? null, req.user.id);
    const user = db
      .prepare(
        `
    SELECT u.id, u.username, u.email, u.display_name AS displayName, u.bio, u.created_at AS createdAt,
      (SELECT COUNT(*) FROM posts WHERE user_id = u.id) AS postCount,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount,
      (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS followingCount
    FROM users u WHERE u.id = ?
  `,
      )
      .get(req.user.id);
    return res.json({ user });
  },
);

router.put(
  '/me',
  requireAuth,
  [
    body('displayName').optional().trim().isLength({ min: 1, max: 40 }),
    body('bio').optional().trim().isLength({ max: 160 }),
  ],
  validate,
  (req, res) => {
    const { displayName, bio } = req.body;
    if (displayName === undefined && bio === undefined)
      return res.status(400).json({ error: 'Add a display name or bio to update.' });
    db.prepare(
      'UPDATE users SET display_name = COALESCE(?, display_name), bio = COALESCE(?, bio) WHERE id = ?',
    ).run(displayName ?? null, bio ?? null, req.user.id);
    return res.json({
      user: db
        .prepare(
          `
    SELECT u.id, u.username, u.email, u.display_name AS displayName, u.bio, u.created_at AS createdAt,
      (SELECT COUNT(*) FROM posts WHERE user_id = u.id) AS postCount,
      (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount,
      (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS followingCount
    FROM users u WHERE u.id = ?
  `,
        )
        .get(req.user.id),
    });
  },
);

router.put(
  '/me/password',
  requireAuth,
  [
    body('currentPassword').isString().isLength({ min: 1, max: 72 }),
    body('newPassword').isString().isLength({ min: 8, max: 72 }),
  ],
  validate,
  (req, res) => {
    const bcrypt = require('bcrypt');
    const user = db
      .prepare('SELECT password_hash AS passwordHash FROM users WHERE id = ?')
      .get(req.user.id);
    if (!user || !bcrypt.compareSync(req.body.currentPassword, user.passwordHash))
      return res.status(400).json({ error: 'Current password is incorrect.' });
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(
      bcrypt.hashSync(req.body.newPassword, 12),
      req.user.id,
    );
    return res.json({ message: 'Password updated.' });
  },
);

router.post('/users/:username/follow', requireAuth, (req, res) => {
  const target = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username);
  if (!target) return res.status(404).json({ error: 'That profile could not be found.' });
  if (target.id === req.user.id)
    return res.status(400).json({ error: 'You cannot follow yourself.' });
  const existing = db
    .prepare('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?')
    .get(req.user.id, target.id);
  if (existing) {
    db.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').run(
      req.user.id,
      target.id,
    );
  } else {
    db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(
      req.user.id,
      target.id,
    );
    notify(target.id, req.user.id, 'follow');
  }
  const followerCount = db
    .prepare('SELECT COUNT(*) AS count FROM follows WHERE following_id = ?')
    .get(target.id).count;
  return res.json({ following: !existing, followerCount });
});

function listPeople(listName, req, res) {
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username);
  if (!user) return res.status(404).json({ error: 'That profile could not be found.' });
  const column = listName === 'followers' ? 'following_id' : 'follower_id';
  const relatedColumn = listName === 'followers' ? 'follower_id' : 'following_id';
  const users = db
    .prepare(
      `
    SELECT u.id, u.username, u.display_name AS displayName, u.bio,
      EXISTS(SELECT 1 FROM follows own WHERE own.follower_id = ? AND own.following_id = u.id) AS followedByMe
    FROM follows f JOIN users u ON u.id = f.${relatedColumn}
    WHERE f.${column} = ? ORDER BY u.username COLLATE NOCASE
  `,
    )
    .all(req.user?.id || 0, user.id);
  return res.json({ users });
}

router.get('/users/:username/followers', optionalAuth, (req, res) =>
  listPeople('followers', req, res),
);
router.get('/users/:username/following', optionalAuth, (req, res) =>
  listPeople('following', req, res),
);

router.get('/messages', requireAuth, (req, res) => {
  const conversations = db
    .prepare(
      `
    WITH peers AS (
      SELECT CASE WHEN sender_id = @userId THEN receiver_id ELSE sender_id END AS peer_id,
        MAX(id) AS last_id
      FROM messages WHERE sender_id = @userId OR receiver_id = @userId
      GROUP BY CASE WHEN sender_id = @userId THEN receiver_id ELSE sender_id END
    )
    SELECT u.username, u.display_name AS displayName, m.content AS lastMessage,
      m.created_at AS lastMessageAt, m.sender_id AS lastSenderId,
      (SELECT COUNT(*) FROM messages unread WHERE unread.sender_id = u.id
        AND unread.receiver_id = @userId AND unread.read_at IS NULL) AS unreadCount
    FROM peers JOIN users u ON u.id = peers.peer_id
    JOIN messages m ON m.id = peers.last_id
    ORDER BY m.created_at DESC, m.id DESC
  `,
    )
    .all({ userId: req.user.id });
  return res.json({ conversations });
});

router.get('/messages/:username', requireAuth, (req, res) => {
  const peer = db
    .prepare('SELECT id, username, display_name AS displayName FROM users WHERE username = ?')
    .get(req.params.username);
  if (!peer) return res.status(404).json({ error: 'That profile could not be found.' });
  db.prepare(
    "UPDATE messages SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE sender_id = ? AND receiver_id = ? AND read_at IS NULL",
  ).run(peer.id, req.user.id);
  const messages = db
    .prepare(
      `
    SELECT id, sender_id AS senderId, receiver_id AS receiverId, content,
      created_at AS createdAt, read_at AS readAt
    FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ORDER BY created_at, id
  `,
    )
    .all(req.user.id, peer.id, peer.id, req.user.id);
  return res.json({ user: peer, messages });
});

router.post(
  '/messages/:username',
  requireAuth,
  [body('content').isString().trim().isLength({ min: 1, max: 2000 })],
  validate,
  (req, res) => {
    const peer = db.prepare('SELECT id FROM users WHERE username = ?').get(req.params.username);
    if (!peer) return res.status(404).json({ error: 'That profile could not be found.' });
    if (peer.id === req.user.id)
      return res.status(400).json({ error: 'You cannot message yourself.' });
    const result = db
      .prepare('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)')
      .run(req.user.id, peer.id, req.body.content);
    const message = db
      .prepare(
        'SELECT id, sender_id AS senderId, receiver_id AS receiverId, content, created_at AS createdAt, read_at AS readAt FROM messages WHERE id = ?',
      )
      .get(result.lastInsertRowid);
    return res.status(201).json({ message });
  },
);

router.get('/notifications', requireAuth, (req, res) => {
  const notifications = db
    .prepare(
      `
    SELECT n.id, n.type, n.post_id AS postId, n.read_at AS readAt, n.created_at AS createdAt,
      a.username AS actorUsername, a.display_name AS actorDisplayName,
      p.content AS postContent
    FROM notifications n JOIN users a ON a.id = n.actor_id
    LEFT JOIN posts p ON p.id = n.post_id
    WHERE n.user_id = ? ORDER BY n.created_at DESC, n.id DESC LIMIT 100
  `,
    )
    .all(req.user.id);
  const unreadCount = db
    .prepare('SELECT COUNT(*) AS count FROM notifications WHERE user_id = ? AND read_at IS NULL')
    .get(req.user.id).count;
  return res.json({ notifications, unreadCount });
});

router.post('/notifications/read', requireAuth, (req, res) => {
  db.prepare(
    "UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE user_id = ? AND read_at IS NULL",
  ).run(req.user.id);
  return res.json({ unreadCount: 0 });
});

module.exports = router;
