const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();
const userById = db.prepare(`
  SELECT u.id, u.username, u.email, u.display_name AS displayName, u.bio, u.created_at AS createdAt,
    (SELECT COUNT(*) FROM posts WHERE user_id = u.id) AS postCount,
    (SELECT COUNT(*) FROM follows WHERE following_id = u.id) AS followerCount,
    (SELECT COUNT(*) FROM follows WHERE follower_id = u.id) AS followingCount
  FROM users u WHERE u.id = ?
`);
const registrationRules = [
  body('username')
    .trim()
    .matches(/^[a-zA-Z0-9_]{3,20}$/)
    .withMessage('Username must be 3–20 letters, numbers, or underscores.'),
  body('email').trim().isEmail().withMessage('Enter a valid email address.').normalizeEmail(),
  body('password')
    .isLength({ min: 8, max: 72 })
    .withMessage('Password must be at least 8 characters.'),
  body('displayName')
    .trim()
    .isLength({ min: 1, max: 40 })
    .withMessage('Display name must be 1–40 characters.'),
];

function validationMessage(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });
  next();
}

function issueSession(userId, res) {
  const token = jwt.sign({ id: userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.COOKIE_SECURE === 'true',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

router.post('/register', registrationRules, validationMessage, (req, res, next) => {
  try {
    const { username, email, password, displayName } = req.body;
    if (db.prepare('SELECT 1 FROM users WHERE username = ? OR email = ?').get(username, email)) {
      return res.status(409).json({ error: 'That username or email is already in use.' });
    }
    const result = db
      .prepare(
        `
      INSERT INTO users (username, email, password_hash, display_name)
      VALUES (?, ?, ?, ?)
    `,
      )
      .run(username, email, bcrypt.hashSync(password, 12), displayName);
    issueSession(result.lastInsertRowid, res);
    return res.status(201).json({ user: userById.get(result.lastInsertRowid) });
  } catch (error) {
    return next(error);
  }
});

router.post(
  '/login',
  [body('email').trim().isEmail().normalizeEmail(), body('password').isString()],
  validationMessage,
  (req, res) => {
    const user = db
      .prepare('SELECT id, password_hash FROM users WHERE email = ?')
      .get(req.body.email);
    if (!user || !bcrypt.compareSync(req.body.password, user.password_hash)) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }
    issueSession(user.id, res);
    return res.json({ user: userById.get(user.id) });
  },
);

router.post('/logout', (_req, res) => {
  res.clearCookie('token', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.COOKIE_SECURE === 'true',
    path: '/',
  });
  res.json({ message: 'You are signed out.' });
});

router.get('/me', requireAuth, (req, res) => {
  const user = userById.get(req.user.id);
  if (!user) return res.status(401).json({ error: 'This account is no longer available.' });
  return res.json({ user });
});

module.exports = router;
