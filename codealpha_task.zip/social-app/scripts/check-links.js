const fs = require('node:fs/promises');
const path = require('node:path');

const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
const publicDir = path.join(__dirname, '..', 'public');
const pageRoutes = [
  '/',
  '/welcome',
  '/root.css',
  '/login',
  '/register',
  '/explore',
  '/post/1',
  '/u/kenny',
  '/u/kenny/followers',
  '/u/kenny/following',
  '/notifications',
  '/messages',
  '/messages/maya',
  '/settings',
];
const bad = [];
const checked = new Set();

async function check(reference, source) {
  let url;
  try {
    url = new URL(reference, `${baseUrl}/`);
  } catch {
    return;
  }
  if (url.origin !== new URL(baseUrl).origin || url.hash) return;
  const target = `${url.pathname}${url.search}`;
  if (checked.has(target)) return;
  checked.add(target);
  try {
    const response = await fetch(new URL(target, baseUrl), { redirect: 'manual' });
    if (response.status < 200 || response.status >= 300)
      bad.push(`${source}: ${target} returned ${response.status}`);
  } catch (error) {
    bad.push(`${source}: ${target} failed (${error.message})`);
  }
}

async function main() {
  for (const route of pageRoutes) await check(route, 'page route');
  const files = (await fs.readdir(publicDir))
    .filter((name) => name.endsWith('.html'))
    .map((filename) => ({ filename, filePath: path.join(publicDir, filename) }));
  files.push({
    filename: 'index.html (welcome)',
    filePath: path.join(__dirname, '..', 'index.html'),
  });
  for (const { filename, filePath } of files) {
    const html = await fs.readFile(filePath, 'utf8');
    if (filename !== 'index.html (welcome)') await check(`/${filename}`, filename);
    for (const match of html.matchAll(/\bhref\s*=\s*["']([^"']+)["']/gi)) {
      const href = match[1].trim();
      if (!href || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:'))
        continue;
      await check(href, filename);
    }
  }
  if (bad.length) {
    console.error(
      `Found ${bad.length} broken internal link(s):\n${bad.map((item) => `- ${item}`).join('\n')}`,
    );
    process.exitCode = 1;
    return;
  }
  console.log(`Checked ${checked.size} internal routes and assets. All returned 2xx.`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
